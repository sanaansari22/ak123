package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.GenieGenericsService;
import com.standardchartered.genie.downloader.replicator.listener.SystemOutLoggerReplicatorListener;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.core.util.SeleniumAssertionUtil;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.bs.A;
import cucumber.api.java.en.And;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static com.standardchartered.eqconnect.module.glue.genericGlue.waitfor;
import static com.standardchartered.genie.module.selenium.core.util.SeleniumAssertionUtil.assertTextIsPresentOnElement;

public class CNSD {

    private GenieScenario scenario;
    private SeleniumService service;
    private GenieGenericsService GenieService;


    @Before("@selenium")
    public void beforeScenario(Scenario scenario) {
        this.scenario = (GenieScenario) scenario;
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");
    }

    @And("^scroll to the bottom$")
    public void scrolltothebottom() {
//        service.getWebDriver().findElement(service.getLookupBy("ExpandButton")).click();
        waitfor(3);
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("window.scrollTo(0,document.body.scrollHeight");
        waitfor(3);
    }

    @And("^scroll to the bottom of '(.+)'$")
    public void scrolltothebottomof(String ele) {
        waitfor(3);
        WebElement container =  service.getWebDriver().findElement(service.getLookupBy(ele));
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;",container);
        waitfor(3);
    }
    @And("^Subtract '([0-9]+)' from '(.+)'$")
    public void Arthimeticsubtract(int y,String x){
       /* System.out.println((String) scenario.getAttribute(x));
        System.out.println(Integer.parseInt((String) scenario.getAttribute(x)));
        System.out.println(Integer.parseInt(scenario.getAttribute(x)) - y);
        System.out.println(y);*/
        scenario.setAttribute(x, Integer.parseInt((String) scenario.getAttribute(x)) - y);
    }

    @And("^Add '([0-9]+)' to '(.+)'$")
    public void ArthimeticAddition(int y,String x){
       /* System.out.println((String) scenario.getAttribute(x));
        System.out.println(Integer.parseInt((String) scenario.getAttribute(x)));
        System.out.println(Integer.parseInt(scenario.getAttribute(x)) - y);
        System.out.println(y);*/
        scenario.setAttribute(x, Integer.parseInt((String) scenario.getAttribute(x)) + y);
    }

    @And("^special type text '(.+)' into '(.+)'$")
    public void specialEnterText(String val, String ele) {
        WebElement container =  service.getWebDriver().findElement(service.getLookupBy(ele));
        waitfor(3);
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("arguments[0].value = arguments[1]",container,val);
        waitfor(3);
    }

    @And("^special type value of '(.+)' into '(.+)'$")
    public void specialEnterValueOfText(String val, String ele) {
        WebElement container =  service.getWebDriver().findElement(service.getLookupBy(ele));
        waitfor(3);
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("arguments[0].value = arguments[1]",container,scenario.getAttribute(val));
        waitfor(3);
    }
    @And("^quick read all terms links for enabling checkbox$")
    public void jsClickAllTerms(){
        WebDriver driver = service.getWebDriver();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement e1 = driver.findElement(service.getLookupBy("Acknowledgements Product Level Terms and Conditions"));
        WebElement e2 = driver.findElement(service.getLookupBy("Acknowledgements General Terms"));
        WebElement e3 = driver.findElement(service.getLookupBy("Acknowledgements Client Declaration of Online transaction"));
        WebElement e4 = driver.findElement(service.getLookupBy("Acknowledgements European Economic Area or United States of America"));
        WebElement e5 = driver.findElement(service.getLookupBy("Acknowledgements Consent Letter for Personal Sensitive Information"));
        WebElement e6 = driver.findElement(service.getLookupBy("Acknowledgements Consent Letter for Third Party Disclosure of Personal Information"));
        js.executeScript("arguments[0].click();arguments[1].click();arguments[2].click();arguments[3].click();arguments[4].click();arguments[5].click();",e1,e2,e3,e4,e5,e6);
    }

    @And("^select product '(.+)' from products catalogue filter$")
    public void selectProductFromCatalogueFilter(String productName) {
        WebDriver driver = service.getWebDriver();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String xpath = "//*[@class='filter-modal__selection']//*[text()='" + productName + "']";
        WebElement productElement = driver.findElement(By.xpath(xpath));
        productElement.click();
    }

    //li[text()= 'Worst Of Basket Autocall']/preceding-sibling::li

    @And("^select product '(.+)' from tailor made catalogue$")
    public void selectTailorMadeProduct(String productName) {
        WebDriver driver = service.getWebDriver();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String xpath = "//li[text()= '" + productName + "']/preceding-sibling::li";
        WebElement productElement = driver.findElement(By.xpath(xpath));
        productElement.click();
    }


    @And("^search and add underlying '(.+)' from tailormade$")
    public void searchAndSelectUnderlying(String underlying) throws InterruptedException {
        if (!underlying.isEmpty() && !underlying.equals("null")) {
            WebElement searchUnderlying = service.getWebDriver().findElement(service.getLookupBy("Tailor Made Search Underlying"));
            searchUnderlying.sendKeys(underlying);
            waitfor(3);
            service.getWebDriver().findElement(service.getLookupBy("Tailor Made add underlying")).click();
            waitfor(3);
            service.getWebDriver().findElement(service.getLookupBy("Tailor Made Clear Results")).click();
        }
    }
}
