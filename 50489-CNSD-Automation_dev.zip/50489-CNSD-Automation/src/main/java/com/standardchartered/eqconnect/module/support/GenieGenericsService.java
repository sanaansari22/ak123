package com.standardchartered.eqconnect.module.support;
import java.lang.*;

public class GenieGenericsService extends java.util.AbstractMap.SimpleEntry {


    public GenieGenericsService(Object key, Object value) {
        super(key, value);
    }


    @Override
    public Object getKey() {
        return super.getKey();
    }
    @Override
    public Object getValue(){
        return super.getValue();
    }

    @Override
    public Object setValue(Object value) {
        return super.setValue(value);
    }

}
