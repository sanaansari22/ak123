package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.GenieGenericsService;
import com.standardchartered.eqconnect.module.support.excelDriver;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.java.transformer.TimeUnitTransformer;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.core.util.SeleniumAssertionUtil;
import com.standardchartered.genie.module.selenium.glue.transformer.LookupByTransformer;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.Before;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import gherkin.pickles.PickleRow;
import org.apache.commons.math3.random.RandomDataGenerator;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class genericGlue {

    private GenieScenario genieScenario;
    private SeleniumService service;
    private GenieGenericsService GenieService;

    @Before("@selenium")
    public void beforeScenario(Scenario scenario) {
        this.genieScenario = (GenieScenario) scenario;
        this.service = this.genieScenario.getRuntime().getAttribute("seleniumService");
    }

    //    And Select 'click advisory reason' from 'select execution only'
    @And("^Select '(.+)' from '(.+)'$")
    public void selectDropdown(String dropdownval, String dropdownname) {

        if (service.getWebDriver().findElement(service.getLookupBy(dropdownname)).getTagName().equals("select")) {
            Select ReportType = new Select(service.getWebDriver().findElement(service.getLookupBy(dropdownname)));
            ReportType.selectByVisibleText(dropdownval);
        } else {
            service.getWebDriver().findElement(service.getLookupBy(dropdownname)).click();
            waitfor(1);
            service.getWebDriver().findElement(service.getLookupBy(dropdownval)).click();
        }
    }

    @When("^select '(.+)' index from '(.+)'$")
    public void selectByIndex(int dropdownval, String dropdownname) {
        Select dropdownElement = new Select(service.getWebDriver().findElement(service.getLookupBy(dropdownname)));
        dropdownElement.selectByIndex(dropdownval);
        waitfor(1);
    }

    @And("^Element Wait$")
    public void element_wait() throws InterruptedException {
        Thread.sleep(4000);
    }

    @And("^wait for (.+) secs$")
    public static void waitfor(int x) {
        try {
            Thread.sleep(x * 1000L);
        } catch (Exception e) {
        }
    }

    @And("^click '(.+)' if exists$")
    public void Click_if_exists(String ele) {
        if (!service.getWebDriver().findElements(service.getLookupBy(ele)).isEmpty()) {
            service.getWebDriver().findElement(service.getLookupBy(ele)).click();
        }
    }

    @And("^click '(.+)' if enabled$")
    public void Click_if_enabled(String ele) {
        if (service.getWebDriver().findElement(service.getLookupBy(ele)).isEnabled()) {
            service.getWebDriver().findElement(service.getLookupBy(ele)).click();
        }
    }

    @And("Click best price button")
    public void best_price_order() {
        String issuerName = service.getWebDriver().findElement(service.getLookupBy("PVB best price provider")).getAttribute("value");
        issuerName = "PVB " + issuerName + " Price button";
        service.getWebDriver().findElement(service.getLookupBy(issuerName)).click();

    }

    @And("^assert the page doesnt contain '(.+)'$")
    public void assertTextNotPresentInPage(String text) {
        Assert.assertFalse(service.getWebDriver().getPageSource().contains(text));
    }

    @And("^assert the page contain '(.+)'$")
    public void assertTextPresentInPage(String text) {
        Assert.assertTrue(service.getWebDriver().getPageSource().contains(text));
    }

    @And("^get value of '(.+)' and save in '(.+)'$")
    public void getValueAndSaveIn(String ele, String varName) {
        String varVal = service.getWebDriver().findElement(service.getLookupBy(ele)).getText();
        genieScenario.setAttribute(varName, varVal);
        waitfor(2);
    }

    @And("^Upload File '(.+)'$")
    public void uploadFile(String filename) throws AWTException {
        Robot rb = new Robot();
        File file = new File(filename);
        StringSelection file_destination = new StringSelection(file.getAbsolutePath());
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(file_destination, null);

        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);

        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyRelease(KeyEvent.VK_V);

        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
    }

    @Then("^assert that '(.+)' is not editable" + TimeUnitTransformer.OPTIONAL_TIMEOUT)
    public void assertThatCheckboxNamedAsIsNotEditable(@Transform(LookupByTransformer.class) By lookup, Long duration, @Transform(TimeUnitTransformer.class) TimeUnit timeUnit) {
        SeleniumAssertionUtil.assertElementIsDisabled(service.getWebDriverWait(duration, timeUnit), lookup);
    }

    @And("^get attribute '(.+)' value of '(.+)' and save in '(.+)'$")
    public void getpropertyValueAndSaveIn(String attribute, String ele, String varName) {
        String varVal = service.getWebDriver().findElement(service.getLookupBy(ele)).getAttribute(attribute);
        service.getScreenShooter().takeScreenshot(genieScenario);
        genieScenario.setAttribute(varName, varVal);
    }

    @And("Send 'TAB' key to '(.+)'$")
    public void sendTabKeyToElement(String elementName) {
        WebElement element = service.getWebDriver().findElement(service.getLookupBy(elementName));
        element.sendKeys(Keys.TAB);
    }

    @And("^jsclick '(.+)'$")
    public void jsclick(String ele) {
        WebElement pwInput = service.getWebDriver().findElement(service.getLookupBy(ele));
        ((JavascriptExecutor) this.service.getWebDriver()).executeScript("arguments[0].click()", pwInput);
    }

    @And("^read data from '(.+)' and type into '(.+)'$")
    public void typeFromData(String ScriptName, String name, DataTable table) {
        for (PickleRow pickleRow : table.getPickleRows()) {
            if (pickleRow.getCells().get(0).getValue().equals(ScriptName)) {
                service.getWebDriver().findElement(service.getLookupBy(name)).sendKeys(pickleRow.getCells().get(1).getValue());
                break;
            }
        }
    }

    @And("^read data from '(.+)' and click$")
    public void performClickFromData(String ScriptName, DataTable table) {
        for (PickleRow pickleRow : table.getPickleRows()) {
            if (pickleRow.getCells().get(0).getValue().equals(ScriptName)) {
                service.getWebDriver().findElement(service.getLookupBy(pickleRow.getCells().get(1).getValue())).click();
                break;
            }
        }
    }

    @And("^StoreGeneratedTranche '(.+)'$")
    public void storegeneratedtrancheTrancheNo(String TrancheNo) {
        String trancheNo = service.getWebDriver().findElement(By.id("ctl00_MainContent_lblStatus")).getAttribute("innerText");
        genieScenario.setAttribute(TrancheNo, trancheNo.split("PRR5")[0]);
    }

    @And("^checkForRequestToContinue$")
    public void checkForRequestToContinue() {
        if (!service.getWebDriver().findElements(By.xpath("//*[@id='btnOk']")).isEmpty()) {
            service.getWebDriver().findElement(By.xpath("//*[@id='btnOk']")).click();
        }
    }

    @And("^read attribute value from '(.+)' and type into '(.+)'$")
    public void TypeAttributeValue(String attributeName, String name) {
        waitfor(1);
        service.getWebDriver().findElement(service.getLookupBy(name)).sendKeys(genieScenario.getAttribute(attributeName).toString());
        waitfor(1);
    }

    @And("^type keys '(.+)' into '(.+)'$")
    public void typeKeysInto(String keys, String name) {
        if (keys.equalsIgnoreCase("ENTER"))
            service.getWebDriver().findElement(service.getLookupBy(name)).sendKeys(Keys.RETURN);
    }

    @And("^Generate '(.+)' digit number and store it in '(.+)'$")
    public void generateRandomNumbers(int arg0, String varName) {
        Random random = new Random();
        long val = new RandomDataGenerator().nextLong((long) Math.pow(10, arg0 - 1), (long) (9 * Math.pow(10, arg0 - 1)));
        genieScenario.setAttribute(varName, val);
        System.out.println(val);
    }

    @And("^Assign '(.+)' to '(.+)'$")
    public void assignTo(String value, String varName) {
        genieScenario.setAttribute(varName, value);
    }

    @Then("^assert that '(.+)' contains value of '(.+)'" + TimeUnitTransformer.OPTIONAL_TIMEOUT)
    public void assertTextIsPresentOnElement(@Transform(LookupByTransformer.class) By elementLookup, String expectedText, Long duration, @Transform(TimeUnitTransformer.class) TimeUnit timeUnit) {
        SeleniumAssertionUtil.assertTextIsPresentOnElement(service.getWebDriverWait(duration, timeUnit), elementLookup, genieScenario.getAttribute(expectedText).toString());
    }

    @And("^assert the page contain value of '(.+)'$")
    public void assertTextValuePresentInPage(String text) {
        Assert.assertTrue(service.getWebDriver().getPageSource().contains(genieScenario.getAttribute(text).toString()));
    }

    @And("^assert that attribute '(.+)' of '(.+)' contains value of '(.+)'" + TimeUnitTransformer.OPTIONAL_TIMEOUT)
    public void assertElementAttributeContains(String attributeName, @Transform(LookupByTransformer.class) By lookupBy, String expected, Long duration, @Transform(TimeUnitTransformer.class) TimeUnit timeUnit) {
        SeleniumAssertionUtil.assertElementAttributeContains(service.getWebDriverWait(duration, timeUnit), lookupBy, attributeName, genieScenario.getAttribute(expected).toString());
    }

    @And("^Read the property '(.+)' from excel '(.+)'$")
    public void readExcelData(String paramName, String TestCaseName) {
        excelDriver excel = new excelDriver();
        genieScenario.setAttribute(paramName, excel.getCellValue(outputFileName(), TestCaseName, paramName));
    }

    @And("Read the property of '(.+)' for '(.+)' from excel '(.+)'")
    public void readspecificExcelData(String paramName, String TestCaseName, String excelPath) {
        excelDriver excel = new excelDriver();
        genieScenario.setAttribute(paramName, excel.getCellValue(excelPath, TestCaseName, paramName));
    }

    @And("^Set value '(.+)' to property '(.+)' in excel '(.+)'$")
    public void setExcelData(String paramVal, String paramName, String TestcaseName) {
        excelDriver excel = new excelDriver();
        excel.setCellValue(outputFileName(), TestcaseName, paramName, paramVal);
    }

    @And("^Write '(.+)' to excel '(.+)'$")
    public void setPropertyExcelData(String paramName, String TestcaseName) {
        excelDriver excel = new excelDriver();
        excel.setCellValue(outputFileName(), TestcaseName, paramName, genieScenario.getAttribute(paramName).toString());
    }

    @And("^print the property '(.+)'$")
    public void printProperty(String propName) {
        System.out.println("Property Name - " + propName);
        System.out.println("Property Value - " + genieScenario.getAttribute(propName));
        System.out.println(genieScenario.getUri());
        System.out.println(outputFileName());
    }

    public String outputFileName() {
        String temp = genieScenario.getUri().replace("feature", "");
        temp = temp.replace("s/", "");
        return temp.replace(".", "");
    }

    @And("^assert that '(.+)' exists '(.+)'$")
    public void assertThatRetailRMWPPCheckExistsVisibility(String ele, boolean result) {
        Assert.assertEquals(!service.getWebDriver().findElements(service.getLookupBy(ele)).isEmpty(), result);
    }

    @And("^Create search text for document generation - '(.+)' & '(.+)'$")
    public void GeneratedDocSearchText(String productName, String TrancheID) {
        genieScenario.setAttribute("searchTxtApplnForm", genieScenario.getAttribute(TrancheID).toString().trim() + "_EQ_" + productName + "_APPLICATIONFORM");
        genieScenario.setAttribute("searchTxtFactsheet", genieScenario.getAttribute(TrancheID).toString().trim() + "_EQ_" + productName + "_FACTSHEET");
        System.out.println(genieScenario.getAttribute("searchTxtApplnForm").toString());
        System.out.println(genieScenario.getAttribute("searchTxtFactsheet").toString());
    }

    @Then("^Assert that row '(.+)' and column '(.+)' of table '(.+)' contains value of '(.+)'")
    public void assertTableValueParam(int row, int column, String elementLookup, String expectedText) {
        WebElement table = service.getWebDriver().findElement(service.getLookupBy(elementLookup));
        Assert.assertTrue(table.findElement(By.xpath("//tr[" + row + "]/td[" + column + "]/span")).getText().contains(genieScenario.getAttribute(expectedText).toString()));
    }

    @Then("^Assert that row '(.+)' and column '(.+)' of table '(.+)' contains '(.+)'")
    public void assertTableValue(int row, int column, String elementLookup, String expectedText) {
        WebElement table = service.getWebDriver().findElement(service.getLookupBy(elementLookup));
        Assert.assertTrue(table.findElement(By.xpath("//tr[" + row + "]/td[" + column + "]/span")).getText().contains(expectedText));
    }

    @And("^Read attribute value and select option '(.+)' from '(.+)'$")
    public void selectOptionFromDropdown(String dropdownvalAttributeName, String dropdownname) {

        if (service.getWebDriver().findElement(service.getLookupBy(dropdownname)).getTagName().equals("select")) {
            Select dropdownElement = new Select(service.getWebDriver().findElement(service.getLookupBy(dropdownname)));
            dropdownElement.selectByVisibleText(genieScenario.getAttribute(dropdownvalAttributeName).toString());
        } else {
            service.getWebDriver().findElement(service.getLookupBy(dropdownname)).click();
            waitfor(1);
            service.getWebDriver().findElement(service.getLookupBy(genieScenario.getAttribute(dropdownvalAttributeName).toString())).click();
        }
    }

    @And("^wait for (.+) secs untill counterparty price is visible$")
    public void waitUntillPriceIsVisible(int x) {

        List<WebElement> counterPartyLabelElement = service.getWebDriver().findElements(service.getLookupBy("Counterparty Name"));

        if (!(service.getWebDriver().findElement(service.getLookupBy("RFQ Label")).getText().contains("RFQ placement not allowed for the selected date")) ) {
            for (int i = 1; i <= counterPartyLabelElement.size(); i++) {

                String dynamicXPathForPrice = "(//*[contains(@class,'LPPrice')])" + "[" + i + "]";
                String dynamicXPathForCounterPartyName = "(//*[@class='lbl BestLP'])" + "[" + i + "]";

                try {
                    waitfor(2);

                    WebElement counterPartyPrice = service.getWebDriver().findElement(By.xpath(dynamicXPathForPrice));
                    WebElement counterPartyName = service.getWebDriver().findElement(By.xpath(dynamicXPathForCounterPartyName));
                    // By price = By.xpath(dynamicXPathForPrice);
                    // service.getWebDriverWait((long) x, TimeUnit.SECONDS).until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElement(priceElement_tst,"")));
                    service.getWebDriverWait((long) x, TimeUnit.SECONDS).until(ExpectedConditions.visibilityOf(counterPartyPrice));
                    service.getWebDriverWait((long) x, TimeUnit.SECONDS).until(ExpectedConditions.textMatches(By.xpath(dynamicXPathForPrice), Pattern.compile("\\d+")));
                    System.out.println("Counterparty Name is : " + counterPartyName.getText() + " and price for the " + counterPartyName.getText() + " is " + counterPartyPrice.getText());

                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    //Assert.fail("Price is not available for the Counterparty : " + service.getWebDriver().findElement(By.xpath(dynamicXPathForCounterPartyName)).getText());
                }
            }
        }
    }

    @And("^wait till client cutoff time is reached - '(.+)','(.+)'$")
    public void waitTillClientCutOffTimeIsReached(String TestCaseName,String expectedTrancheStatus) {

        waitTillEndTimeIsReached(TestCaseName,expectedTrancheStatus,"clientCutOffExpectedDate","clientCutOffExpectedHour","clientCutOffExpectedMinutes","clientCutOffExpectedHourFormat");
    }

    @And("^wait till cooling period end time is reached - '(.+)','(.+)'$")
    public void waitTillCoolingPeriodEndTimeIsReached(String TestCaseName,String expectedTrancheStatus) {

        waitTillEndTimeIsReached(TestCaseName,expectedTrancheStatus,"coolingPeriodExpectedDate","coolingPeriodExpectedHour","coolingPeriodExpectedMinutes","coolingPeriodExpectedHourFormat");
    }

    @And("^wait till window period end time is reached - '(.+)','(.+)'$")
    public void waitTillWindowPeriodEndTimeIsReached(String TestCaseName,String expectedTrancheStatus) {

        waitTillEndTimeIsReached(TestCaseName,expectedTrancheStatus,"windowPeriodExpectedDate","windowPeriodExpectedHour","windowPeriodExpectedMinutes","windowPeriodExpectedHourFormat");
    }

    public void waitTillEndTimeIsReached(String TestCaseName,String expectedTrancheStatus,String expDate,String expHour,String expMinutes,String expHourFormat) {

        Calendar calendarInstance = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd:hh:mm:a");

        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Singapore"));
        String currentTime = dateFormat.format(calendarInstance.getTime());
        String[] dateAndTime = currentTime.split(":");

        //dayOfMonth
        int date = Integer.parseInt(dateAndTime[0].split("-")[2]);
        int hour = Integer.parseInt(dateAndTime[1]);
        int minutes = Integer.parseInt(dateAndTime[2]);
        String hourFormat = dateAndTime[3];

        readExcelData(expDate, TestCaseName);
        readExcelData(expHour, TestCaseName);
        readExcelData(expMinutes, TestCaseName);
        readExcelData(expHourFormat, TestCaseName);

        int expectedDate = Integer.parseInt(genieScenario.getAttribute(expDate).toString());
        int expectedHour = Integer.parseInt(genieScenario.getAttribute(expHour).toString());
        int expectedMinutes = Integer.parseInt(genieScenario.getAttribute(expMinutes).toString());
        String expectedHourFormat = genieScenario.getAttribute(expHourFormat).toString();
        int count =0;

        while (!((date >= expectedDate) && (hour >= expectedHour) && (minutes >= expectedMinutes) && (hourFormat.equals(expectedHourFormat)) ) ) {

            System.out.println("End time is not yet reached");
            calendarInstance = Calendar.getInstance();
            currentTime = dateFormat.format(calendarInstance.getTime());
            dateAndTime = currentTime.split(":");

            //dayOfMonth
            date = Integer.parseInt(dateAndTime[0].split("-")[2]);

            hour = Integer.parseInt(dateAndTime[1]);
            minutes = Integer.parseInt(dateAndTime[2]);
            hourFormat = dateAndTime[3];

            waitfor(15);
            count++;
            if (count>=60) {
                System.out.println("Waited for 15 minutes before exiting from while loop");
                System.out.println("date : " + date + "\nexpectedDate: " + expectedDate + "\nhour : " + hour + "\nexpectedHour : "+expectedHour + "\nminutes : " + minutes + "\nexpectedMinutes : " + expectedMinutes);
                break;
            }
        }
        waitfor(2);
        service.getWebDriver().findElement(service.getLookupBy("WB Load Button")).click();
        waitfor(5);
        WebElement webElement = service.getWebDriver().findElement(service.getLookupBy("WB Approve First Status"));
        waitfor(3);
        try {
             service.getWebDriverWait((long) 10, TimeUnit.SECONDS).until(ExpectedConditions.textToBePresentInElement(webElement, expectedTrancheStatus));
          } catch (Exception e) {
              System.out.println(e.getMessage());
              Assert.fail("Tranche status is not updated as "+expectedTrancheStatus + " current Tranche status is : " + webElement.getText());
          }
    }

    @And("^type '(.+)' into '(.+)' if text field is displayed and enabled$")
    public void TypeIfTextFieldIsEnabled(String value, String ele) {

        try {
           WebElement textField = service.getWebDriver().findElement(service.getLookupBy(ele));
            String doneAtFieldValue = textField.getAttribute("value");
            if ( (textField.isDisplayed()) && (textField.isEnabled()) && ( (doneAtFieldValue==null) || (doneAtFieldValue.isEmpty()) || (doneAtFieldValue.contains("0.00")) ) ) {
                waitfor(1);
                textField.sendKeys(Keys.CONTROL+"a");
                waitfor(2);
                textField.sendKeys(value);
                waitfor(2);
                service.getWebDriver().findElement(service.getLookupBy("Empty Space on Pricers page")).click();
                waitfor(2);
            }
             } catch (Exception e) {
            System.out.print("Text field is not displayed on the page or is disabled --- Exception message : " + e.getMessage());
       }
    }

    @And("^save tranche number in '(.+)'$")
    public void saveTrancheNumberIn(String varName) {
        String varVal = service.getWebDriver().findElement(service.getLookupBy("UCP success message")).getText();
        service.getScreenShooter().takeScreenshot(genieScenario);
        varVal = varVal.subSequence(varVal.lastIndexOf(" "), varVal.length()).toString();
        System.out.println(varVal);
        genieScenario.setAttribute(varName, varVal);
    }

    @When("^scroll horizontally till element '(.+)' into view$")
    public void scrollElementIntoView(String element) {
        ((JavascriptExecutor)this.service.getWebDriver()).executeScript("arguments[0].scrollIntoView({inline:'center'});", this.service.getWebDriver().findElement(service.getLookupBy(element)));
    }

    @And("^wait for (.+) seconds till element '(.+)' is visible$")
    public void waitUntillElementIsVisible(int x, String element) {
        try {
            WebElement webElement = service.getWebDriver().findElement(service.getLookupBy(element));
            service.getWebDriverWait((long) x, TimeUnit.SECONDS).until(ExpectedConditions.visibilityOf(webElement));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @And("^verify that the file '(.+)' is downloaded and file format is '(.+)'$")
    public void verifyFileIsDownloaded(String fileName,String fileNameExtension) {
        try {
            File downloadedFileDirectory = new File("target/download");
            File[] fileList = downloadedFileDirectory.listFiles();

            if( fileList != null) {
                for (File getFile : fileList) {

                    String downloadedFileExtension = getFile.getName().split("\\.")[1];
                    if ( (getFile.getName().toLowerCase().contains(fileName.toLowerCase())) && (downloadedFileExtension.toLowerCase().contains(fileNameExtension.toLowerCase())) && (getFile.canRead()) ) {
                        System.out.println("File " +getFile.getName() + " is downloaded and readable, exists in the target/download folder");
                        boolean status = getFile.delete();
                        waitfor(1);
                        System.out.println("File delete status : " + status);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @And("^wait for (.+) seconds till element '(.+)' is available$")
    public void waitUntillElementAvailable(int x, String element) {
        try {
            service.getWebDriverWait((long) x, TimeUnit.SECONDS).until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy(element)));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @And("^wait for (.+) seconds till element '(.+)' is clickable$")
    public void waitUntillElementClickable(int x, String element) {
        try {
            service.getWebDriverWait((long) x, TimeUnit.SECONDS).until(ExpectedConditions.elementToBeClickable(service.getLookupBy(element)));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
