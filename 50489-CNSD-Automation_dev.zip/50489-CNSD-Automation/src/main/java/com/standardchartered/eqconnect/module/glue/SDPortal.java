package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.GenieGenericsService;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static com.standardchartered.eqconnect.module.glue.genericGlue.waitfor;

public class SDPortal {

    private GenieScenario scenario;
    private SeleniumService service;
    private GenieGenericsService GenieService;


    @Before("@selenium")
    public void beforeScenario(Scenario scenario) {
        this.scenario = (GenieScenario) scenario;
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");
    }


}
