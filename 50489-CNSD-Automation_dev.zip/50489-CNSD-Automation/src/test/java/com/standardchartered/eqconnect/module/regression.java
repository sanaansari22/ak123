package com.standardchartered.eqconnect.module;

import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;
import com.standardchartered.genie.junit.Genie;

@RunWith(Genie.class)
@CucumberOptions(
        junit = {"--step-notifications"},
        features = {"classpath:features"},
        tags = {"@eqccn"},
        glue = {"classpath:com.standardchartered.eqconnect.module.glue",
                "classpath:snippet"}
)
public class regression {

}
