package com.standardchartered.eqconnect.module.support;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;

/**
 * PandaFileHelper - small utility to read CSV/XLSX row counts (skip header)
 */
public class PandaFileHelper {
    // Returns number of data rows (excluding header)
    public static int getRowCountFromXlsx(String path) throws IOException {
        try (FileInputStream fis = new FileInputStream(new File(path));
             XSSFWorkbook wb = new XSSFWorkbook(fis)) {
            XSSFSheet sheet = wb.getSheetAt(0);
            int physicalRows = sheet.getPhysicalNumberOfRows();
            // If header present, subtract 1; otherwise return physicalRows
            return Math.max(0, physicalRows - 1);
        }
    }

    public static int getRowCountFromCsv(String path) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean headerSkipped = false;
            int count = 0;
            while ((line = br.readLine()) != null) {
                if (!headerSkipped) { headerSkipped = true; continue; }
                if (line.trim().isEmpty()) continue;
                count++;
            }
            return count;
        }
    }
}