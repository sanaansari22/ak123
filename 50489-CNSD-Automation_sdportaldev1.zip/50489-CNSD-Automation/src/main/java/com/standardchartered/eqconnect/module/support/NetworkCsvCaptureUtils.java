package com.standardchartered.eqconnect.module.support;;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v110.network.Network;
import org.openqa.selenium.devtools.v110.network.model.Response;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.*;
        import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;

public class NetworkCsvCaptureUtils {

    private static final Logger logger = Logger.getLogger(NetworkCsvCaptureUtils.class.getName());

    private static AtomicReference<String> apiResponseBody = new AtomicReference<>();
    /**
     * Capture network response of CSV download and save to file.
     *
     * @param driver          WebDriver (EdgeDriver)
     * @param urlContains     Partial URL to match the CSV download request
     * @param destinationFolder Folder where CSV should be saved
     * @param outputFileName  File name to save the CSV as (e.g., "passedname.csv")
     * @param timeoutMs       Maximum wait time in milliseconds
     * @return HTTP status code of the request
     * @throws Exception if download fails or timeout occurs
     */
    public static int captureCsvFromNetwork(WebDriver driver,
                                            String urlContains,
                                            Path destinationFolder,
                                            String outputFileName,
                                            long timeoutMs) throws Exception {

        if (!(driver instanceof HasDevTools)) {
            throw new IllegalStateException("Driver does not support DevTools. Use EdgeDriver.");
        }

        DevTools devTools = ((HasDevTools) driver).getDevTools();
        devTools.createSession();

        final AtomicReference<String> responseBodyRef = new AtomicReference<>();
        final AtomicReference<Integer> statusCodeRef = new AtomicReference<>();
        final AtomicBoolean responseCaptured = new AtomicBoolean(false);

        // Enable network monitoring
        devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

        // Listen for network responses
        devTools.addListener(Network.responseReceived(), event -> {
            Response response = event.getResponse();
            String requestUrl = response.getUrl();
            if (requestUrl.contains(urlContains)) {
                logger.info("📡 Capturing network response for URL: " + requestUrl);
                statusCodeRef.set(response.getStatus());

                try {
                    // Get response body
                    String body = devTools.send(Network.getResponseBody(event.getRequestId())).getBody();
                    responseBodyRef.set(body);
                    responseCaptured.set(true);
                    logger.info("Response captured, status code: " + response.getStatus());
                } catch (Exception e) {
                    logger.severe("Failed to get response body: " + e.getMessage());
                }
            }
        });

        // Wait until response is captured or timeout
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (responseCaptured.get()) break;
            Thread.sleep(200);
        }

        if (!responseCaptured.get()) {
            throw new IllegalStateException("Network CSV response not captured within timeout.");
        }

        // Ensure destination folder exists

        if (!Files.exists(destinationFolder)) {
            Files.createDirectories(destinationFolder);
        }

        Path filePath = destinationFolder.resolve(outputFileName);

        // Save CSV content
        try (FileOutputStream fos = new FileOutputStream(filePath.toFile())) {
            fos.write(responseBodyRef.get().getBytes());
            logger.info("CSV saved to: " + filePath.toAbsolutePath());
        }

        int statusCode = statusCodeRef.get();
        if (statusCode != 200) {
            logger.warning("⚠ HTTP status code is not 200: " + statusCode);
        } else {
            logger.info("HTTP status code 200 OK");
        }

        return statusCode;
    }
    public static String getResponseBody(){
        if(apiResponseBody.get()!=null){
            return apiResponseBody.get();
        }
        return "{}";
    }

    public static String captureNetworkCall(WebDriver driver, String endPoint){
        EdgeDriver localDriver = (EdgeDriver) driver;
        DevTools devTools = localDriver.getDevTools();
        devTools.createSession();
        devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

        devTools.addListener(Network.responseReceived(), responseReceived -> {
            try {
                if (responseReceived.getResponse().getUrl().endsWith(endPoint)) {
                    String body = devTools.send(Network.getResponseBody(responseReceived.getRequestId())).getBody();
                    apiResponseBody.set(body);
                }
            }catch (Exception e){
                throw new RuntimeException("Failure: On fetching response of intercepted call");
            }
                }
                );

        return "";
    }
}
