package com.standardchartered.eqconnect.module.glue;
/*
 * SDPortal_FXSDTrancheUploadGlue.java
 *
 * Author: Sana Ansari
 * Source reference: /mnt/data/FXSD Tranche Upload Test Automation code.docx
 *
 * Purpose:
 *   - This class is the Cucumber/Genie glue (step definitions) for the FXSD Tranche Upload scenario.
 *   - It contains the WebElement interactions: clicks, waits, upload trigger (sendKeys), UI reads and assertions.
 *   - The heavy file / Excel logic is delegated to SDTranchUploadHelper (see the helper file).
 *
 *
 */

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import helpers.SDTranchUploadHelper;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;

public class SDPortal_FXSDTrancheUploadGlue {

    private static final Logger logger = Logger.getLogger(SDPortal_FXSDTrancheUploadGlue.class.getName());

    /**
     * GenieScenario: cast of cucumber Scenario so we can access Genie runtime attributes.
     * Holds runtime objects such as seleniumService and allows storing attributes for cross-scenario use.
     */
    private GenieScenario scenario;

    /**
     * SeleniumService: wrapper around WebDriver provided by Genie.
     * Use this for element lookups, waits and WebDriver access.
     */
    private SeleniumService service;

    /**
     * Page/helper object that does all file & Excel manipulation.
     * Note: the helper does NOT use WebDriver. It returns prepared file paths and saves IDs to Excel.
     */
    private SDTranchUploadHelper uploadHelper;

    // ---------------------------------------------------------------------
    // Before hook: runs before scenarios tagged @selenium
    // ---------------------------------------------------------------------
    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        // 1) Cast Cucumber Scenario to GenieScenario to access runtime attributes
        this.scenario = (GenieScenario) cucumberScenario;

        // 2) Retrieve the SeleniumService instance stored in Genie runtime
        //    The runtime key "seleniumService" is set by the framework when the Selenium module is started.
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");

        // 3) Instantiate the file-helper which will be used to prepare the Excel file
        //    The helper only does file/Excel work (no WebDriver calls).
        this.uploadHelper = new SDTranchUploadHelper();
    }

    // ---------------------------------------------------------------------
    // Step: Upload a file by using a UI element key for the file input
    // Called by snippet: upload file 'CNSD_TRANCHE_UPLOAD_YYYYMMDD.xlsx' using 'SDP Tranches Upload File Input'
    // ---------------------------------------------------------------------
    @And("^upload file '(.+)' using '(.+)'$")
    public void uploadFile(String requestedFileName, String inputElementKey) {

        /*
         * STEP A: Prepare the file (file-copy + ID updates)
         * - All file operations are performed by SDTranchUploadHelper.prepareTrancheFile(...)
         * - This method returns an absolute file path pointing to the generated file ready for upload.
         *
         * Rationale: Keep file I/O out of the glue so web interactions remain isolated here.
         */
        String preparedFileAbsolutePath = uploadHelper.prepareTrancheFile(requestedFileName);
        this.scenario.getRuntime().setAttribute("lastUploadedFilePath", preparedFileAbsolutePath);

        /*
         * STEP B: Resolve the file input element on the UI using the element repository key.
         * - service.getLookupBy(key) resolves friendly element names to Selenium By locators (element JSON).
         * - We deliberately call findElement here (glue owns WebElement interactions).
         */
        By fileInputBy = service.getLookupBy(inputElementKey);
        WebElement fileInput = service.getWebDriver().findElement(fileInputBy);

        /*
         * STEP C: Upload logic (primary strategy: sendKeys on <input type="file">)
         * - If the input is visible we do a direct sendKeys(filePath).
         * - If it is hidden we make it temporarily visible via JS, call sendKeys, then restore style.
         *
         * Notes:
         * - sendKeys on <input type="file"> is supported by Selenium and works on remote Grid / headless.
         * - We keep this logic in glue because it directly interacts with the DOM and might dispatch events.
         */
        try {
            if (fileInput.isDisplayed()) {
                // Visible input → direct upload
                fileInput.sendKeys(preparedFileAbsolutePath);
            } else {
                // Hidden input → temporarily reveal, upload, then hide back
                // Use JavascriptExecutor via service.getWebDriver()
                ((org.openqa.selenium.JavascriptExecutor) service.getWebDriver())
                        .executeScript("arguments[0].style.display='block'; arguments[0].style.visibility='visible';", fileInput);

                // Now send the file path
                fileInput.sendKeys(preparedFileAbsolutePath);

                // Hide the input again to restore original UI
                ((org.openqa.selenium.JavascriptExecutor) service.getWebDriver())
                        .executeScript("arguments[0].style.display='none'; arguments[0].style.visibility='hidden';", fileInput);
            }

        } catch (Exception ex) {
            // If sendKeys fails for any reason (rare), throw runtime exception with details
            // This makes the failure bold in reports; tests should fail visibly rather than silently proceed.
            throw new RuntimeException("File upload failed for file: " + preparedFileAbsolutePath + " - " + ex.getMessage(), ex);
        }
    }

    // ---------------------------------------------------------------------
    // Step: Assert uploaded filename is visible in the UI
    // Called: And assert that uploaded file name is '...' in 'SDP Tranche Uploaded FileName'
    // ---------------------------------------------------------------------
    @And("^assert that uploaded file name is '(.+)' in '(.+)'$")
    public void assertUploadedFileName(String expectedFileName, String uploadedFileNameElementKey) {

        /*
         * The expectedFileName may include placeholders (YYYYMMDD). Replace them with today's date
         * so the assertion matches the generated name.
         */
        String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String expected = expectedFileName.replace("YYYYMMDD", today);

        // Wait for element to be visible and have text
        By elementBy = service.getLookupBy(uploadedFileNameElementKey);
        WebElement uploadedNameElement = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> {
                    WebElement el = driver.findElement(elementBy);
                    String text = el.getText().trim();
                    // Wait until element is visible and has non-empty text
                    return el.isDisplayed() && !text.isEmpty() ? el : null;
                });

        String displayed = uploadedNameElement.getText().trim();
        logger.info("Expected file name: " + expected + ", Displayed: " + displayed);

        // Assert the UI displays expected file name (contains check is safer if UI adds extra text)
        if (!displayed.contains(expected)) {
            throw new AssertionError("Uploaded filename mismatch. Expected to contain: " + expected + " but was: " + displayed);
        }

        // Delete the generated upload file after verification
        String uploadedFilePath = this.scenario.getRuntime().getAttribute("lastUploadedFilePath");
        if (uploadedFilePath != null) {
            uploadHelper.deleteGeneratedUploadFile(uploadedFilePath);
            this.scenario.getRuntime().setAttribute("lastUploadedFilePath", null);
        }
    }

    // ---------------------------------------------------------------------
    // Step: Assert that upload status column contains expected status (e.g. 'SUCCESS')
    // Called: And assert that upload status column contains 'Success' in 'SDP Upload Status Table'
    // ---------------------------------------------------------------------
    @And("^assert that upload status column contains '(.+)' in '(.+)'$")
    public void assertUploadStatus(String expectedStatus, String tableElementKey) {

        // Wait for table to be visible before finding it
        service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> driver.findElement(service.getLookupBy(tableElementKey)).isDisplayed());

        // Find the table container element
        WebElement table = service.getWebDriver().findElement(service.getLookupBy(tableElementKey));

        // Wait for at least one row to be present in the table
        service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> {
                    List<WebElement> rows = table.findElements(org.openqa.selenium.By.cssSelector("tbody tr"));
                    return !rows.isEmpty();
                });

        // Get row elements from table body
        List<WebElement> rows = table.findElements(org.openqa.selenium.By.cssSelector("tbody tr"));

        // Iterate rows and check the status column text for expectedStatus
        boolean found = false;
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(org.openqa.selenium.By.tagName("td"));

            // Defensive: ensure row has expected number of columns (skip otherwise)
            if (cols.size() < 1) continue;

            // Example: business UI may put status in a fixed column (index may vary by UI)
            // We search all columns for the text to be robust; change index if you want an exact column.
            for (WebElement col : cols) {
                if (col.getText().trim().equalsIgnoreCase(expectedStatus)) {
                    found = true;
                    break;
                }
            }
            if (found) break;
        }

        if (!found) {
            throw new AssertionError("Expected upload status '" + expectedStatus + "' not found in table '" + tableElementKey + "'");
        }
    }

    // ---------------------------------------------------------------------
    // Step: Capture tranche IDs from the Upload Status table and save in runtime
    // Called: Then capture tranche ids from 'SDP Upload Status Table' and save as 'lastTrancheIds'
    // ---------------------------------------------------------------------
    @Then("^capture tranche ids from '(.+)' and save as '(.+)'$")
    public void captureTrancheIds(String tableElementKey, String runtimeKey) {

        // 1) Locate the upload table HTML element
        WebElement table = service.getWebDriver().findElement(service.getLookupBy(tableElementKey));

        // 2) Find column indices by header names - check thead first, then first tbody row
        int trancheIdColIdx = -1;
        int windowStartColIdx = -1;
        int windowEndColIdx = -1;
        boolean headerInTbody = false;

        List<WebElement> headerCols = new ArrayList<>();

        // Try multiple strategies to find headers
        // Strategy 1: Find headers in thead > tr > td
        List<WebElement> theadRows = table.findElements(org.openqa.selenium.By.cssSelector("thead tr"));
        if (!theadRows.isEmpty()) {
            WebElement headerRow = theadRows.get(0);
            // Try td elements first (most common)
            headerCols = headerRow.findElements(org.openqa.selenium.By.tagName("td"));
            // If no td found, try th elements
            if (headerCols.isEmpty()) {
                headerCols = headerRow.findElements(org.openqa.selenium.By.tagName("th"));
            }
            // If still empty, try both
            if (headerCols.isEmpty()) {
                headerCols = headerRow.findElements(org.openqa.selenium.By.cssSelector("td, th"));
            }
        }

        // Strategy 2: If thead didn't work, try first tbody row
        if (headerCols.isEmpty()) {
            List<WebElement> tbodyRows = table.findElements(org.openqa.selenium.By.cssSelector("tbody tr"));
            if (!tbodyRows.isEmpty()) {
                WebElement firstRow = tbodyRows.get(0);
                headerCols = firstRow.findElements(org.openqa.selenium.By.tagName("td"));
                if (headerCols.isEmpty()) {
                    headerCols = firstRow.findElements(org.openqa.selenium.By.tagName("th"));
                }
                if (headerCols.isEmpty()) {
                    headerCols = firstRow.findElements(org.openqa.selenium.By.cssSelector("td, th"));
                }
                headerInTbody = true;
            }
        }

        // Strategy 3: Try direct XPath for header cells
        if (headerCols.isEmpty()) {
            headerCols = table.findElements(org.openqa.selenium.By.xpath(".//thead//tr//td[@class='file-upload__header']"));
        }
        if (headerCols.isEmpty()) {
            headerCols = table.findElements(org.openqa.selenium.By.xpath(".//thead//tr//td"));
        }

        // Log all headers found for debugging
        logger.info("Total header columns found: " + headerCols.size());
        for (int i = 0; i < headerCols.size(); i++) {
            String headerText = headerCols.get(i).getText().trim();
            logger.info("Header[" + i + "]: '" + headerText + "'");
        }

        // Find column indices by matching header names (case-insensitive, normalize spaces)
        for (int i = 0; i < headerCols.size(); i++) {
            String headerText = headerCols.get(i).getText().trim();
            // Normalize spaces: replace multiple spaces with single space
            String headerTextNormalized = headerText.replaceAll("\\s+", " ").toLowerCase();
            logger.info("Checking header[" + i + "]: original='" + headerText + "', normalized='" + headerTextNormalized + "'");

            // Match "Tranche ID" (contains check, case-insensitive)
            if (trancheIdColIdx == -1 && headerTextNormalized.contains("tranche") && headerTextNormalized.contains("id")) {
                trancheIdColIdx = i;
                logger.info("✓ Found Tranche ID column at index: " + i + " (header: '" + headerText + "')");
            }
            // Match "Window Period Start Datetime" - check for all required words
            if (windowStartColIdx == -1) {
                boolean hasWindow = headerTextNormalized.contains("window");
                boolean hasPeriod = headerTextNormalized.contains("period");
                boolean hasStart = headerTextNormalized.contains("start");
                boolean hasDatetime = headerTextNormalized.contains("datetime");
                logger.info("  Window Start check[" + i + "]: window=" + hasWindow + ", period=" + hasPeriod +
                        ", start=" + hasStart + ", datetime=" + hasDatetime);
                if (hasWindow && hasPeriod && hasStart && hasDatetime) {
                    windowStartColIdx = i;
                    logger.info("✓ Found Window Start column at index: " + i + " (header: '" + headerText + "')");
                }
            }
            // Match "Window Period End Datetime" - check for all required words
            if (windowEndColIdx == -1) {
                boolean hasWindow = headerTextNormalized.contains("window");
                boolean hasPeriod = headerTextNormalized.contains("period");
                boolean hasEnd = headerTextNormalized.contains("end");
                boolean hasDatetime = headerTextNormalized.contains("datetime");
                logger.info("  Window End check[" + i + "]: window=" + hasWindow + ", period=" + hasPeriod +
                        ", end=" + hasEnd + ", datetime=" + hasDatetime);
                if (hasWindow && hasPeriod && hasEnd && hasDatetime) {
                    windowEndColIdx = i;
                    logger.info("✓ Found Window End column at index: " + i + " (header: '" + headerText + "')");
                }
            }
        }

        // Fallback: Use default column indices if header search failed
        // Based on HTML structure: Window Period Start Datetime = column 7, Window Period End Datetime = column 8
        if (windowStartColIdx == -1) {
            windowStartColIdx = 7; // Default column index for Window Period Start Datetime
            logger.info("Using fallback column index 7 for Window Period Start Datetime");
        }
        if (windowEndColIdx == -1) {
            windowEndColIdx = 8; // Default column index for Window Period End Datetime
            logger.info("Using fallback column index 8 for Window Period End Datetime");
        }
        if (trancheIdColIdx == -1) {
            trancheIdColIdx = 4; // Default column index for Tranche ID
            logger.info("Using fallback column index 4 for Tranche ID");
        }

        // Log column indices for debugging
        logger.info("Final column indices - Tranche ID: " + trancheIdColIdx +
                ", Window Start: " + windowStartColIdx + ", Window End: " + windowEndColIdx);

        // 3) Read data rows (tbody > tr, skip header row if it was in tbody)
        List<WebElement> rows = table.findElements(org.openqa.selenium.By.cssSelector("tbody tr"));
        int startRowIdx = headerInTbody ? 1 : 0;

        // 4) Extract tranche metadata from each row
        List<String> capturedIds = new ArrayList<>();
        List<SDTranchUploadHelper.TrancheUploadRecord> successRecords = new ArrayList<>();
        for (int rowIdx = startRowIdx; rowIdx < rows.size(); rowIdx++) {
            WebElement row = rows.get(rowIdx);
            List<WebElement> cols = row.findElements(org.openqa.selenium.By.tagName("td"));

            if (cols.isEmpty()) continue;

            // Get tranche ID from found column index, fallback to index 0 or 4
            String trancheId = "";
            if (trancheIdColIdx >= 0 && trancheIdColIdx < cols.size()) {
                trancheId = getColumnText(cols, trancheIdColIdx);
            }
            if (trancheId.isEmpty() && cols.size() > 4) {
                trancheId = getColumnText(cols, 4);
            }
            if (trancheId.isEmpty() && cols.size() > 0) {
                trancheId = getColumnText(cols, 0);
            }

            // Get window start/end from found column indices by header name
            String windowStart = "";
            String windowEnd = "";

            logger.info("Row " + rowIdx + " - Total columns: " + cols.size() +
                    ", WindowStartColIdx: " + windowStartColIdx + ", WindowEndColIdx: " + windowEndColIdx);

            if (windowStartColIdx >= 0 && windowStartColIdx < cols.size()) {
                String rawStart = getColumnText(cols, windowStartColIdx);
                windowStart = rawStart != null ? rawStart.trim() : "";
                logger.info("  Window Start extracted from col[" + windowStartColIdx + "]: '" + rawStart + "' -> '" + windowStart + "'");
            } else {
                logger.warning("  Window Start column index " + windowStartColIdx + " is invalid (total cols: " + cols.size() + ")");
            }

            if (windowEndColIdx >= 0 && windowEndColIdx < cols.size()) {
                String rawEnd = getColumnText(cols, windowEndColIdx);
                windowEnd = rawEnd != null ? rawEnd.trim() : "";
                logger.info("  Window End extracted from col[" + windowEndColIdx + "]: '" + rawEnd + "' -> '" + windowEnd + "'");
            } else {
                logger.warning("  Window End column index " + windowEndColIdx + " is invalid (total cols: " + cols.size() + ")");
            }

            // Log for debugging
            logger.info("Row " + rowIdx + " - Tranche ID: '" + trancheId +
                    "', Window Start: '" + windowStart + "', Window End: '" + windowEnd + "'");

            boolean isSuccess = cols.stream()
                    .anyMatch(col -> "success".equalsIgnoreCase(col.getText().trim()));

            if (!trancheId.isEmpty()) {
                capturedIds.add(trancheId);
                if (isSuccess) {
                    successRecords.add(new SDTranchUploadHelper.TrancheUploadRecord(trancheId, windowStart, windowEnd));
                }
            }
        }

        // 5) Store captured list into Genie runtime so other scenarios can use it
        this.scenario.getRuntime().setAttribute(runtimeKey, capturedIds);

        // 6) Persist SUCCESS tranche records (ID + window start/end)
        uploadHelper.saveTrancheRecords(successRecords);
    }

    // Helper method to safely get column text by index - handles span elements inside td
    private String getColumnText(List<WebElement> cols, int index) {
        if (index < 0 || index >= cols.size()) {
            return "";
        }
        WebElement cell = cols.get(index);
        String text = "";

        // Try to get text directly from cell (Selenium getText() handles nested elements)
        try {
            text = cell.getText().trim();
        } catch (Exception e) {
            logger.warning("Failed to get text from cell at index " + index + ": " + e.getMessage());
        }

        // If empty, try to find span inside and get its text
        if (text.isEmpty()) {
            try {
                List<WebElement> spans = cell.findElements(org.openqa.selenium.By.tagName("span"));
                if (!spans.isEmpty()) {
                    // Get text from first non-empty span
                    for (WebElement span : spans) {
                        String spanText = span.getText().trim();
                        if (!spanText.isEmpty()) {
                            text = spanText;
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                // No span found or error, use empty string
            }
        }

        return text;
    }
}
