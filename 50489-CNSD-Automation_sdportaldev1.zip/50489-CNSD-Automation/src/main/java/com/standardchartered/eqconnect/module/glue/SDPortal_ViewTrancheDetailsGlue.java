package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.glue.transformer.LookupByTransformer;
import cucumber.api.Scenario;
import cucumber.api.Transform;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * SDPortal_TrancheApprovalGlue
 *
 * Glue for TC 5578611 (Checker approves FXSD Tranche).
 * Reuses step definitions from SDPortal_TermsheetUploadGlue for search functionality.
 */
public class SDPortal_ViewTrancheDetailsGlue {

    private static final Logger logger = Logger.getLogger(SDPortal_ViewTrancheDetailsGlue.class.getName());
    private SeleniumService service;
    private GenieScenario scenario;

    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        GenieScenario scenario = (GenieScenario) cucumberScenario;
        this.service = scenario.getRuntime().getAttribute("seleniumService");
        if (this.service == null) {
            logger.severe("seleniumService is not initialized");
        } else {
            logger.info("seleniumService is initialized successfully");
        }
    }

    /**
     * Assert that page contains specific text
     * This maps to snippet line: Then assert the page contains 'Tranche Created'
     */
    @Then("^assert the page contains '(.+)'$")
    public void assertPageContains(String expectedText) {
        String pageSource = service.getWebDriver().getPageSource();
        Assert.assertTrue("Page does not contain expected text: " + expectedText,
                pageSource.contains(expectedText));
        logger.info("Verified page contains: " + expectedText);
    }


    /**
     * Verify 'View Tranche Details' page is displayed (title element visible)
     * Step pattern: Then verify 'SDP View Tranche Details Title' page is displayed
     */
    @Then("^verify '(.*)' page is displayed$")
    public void verifyViewTrancheDetailsPage(String pageTitle) {
        WebElement title = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy(pageTitle)));
        Assert.assertTrue("View Tranche Details title not visible", title.isDisplayed());
        logger.info("Verified 'View Tranche Details' page title visible.");
    }

    /**
     * Scroll inside the popup container to the bottom to make approve button visible
     * Uses multiple strategies to ensure button becomes visible
     * Step pattern: And scroll inside popup container to bottom
     */
    @And("^scroll inside popup container to bottom$")
    public void scrollInsidePopupContainerToBottom() {
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();

        try {
            // Strategy 1: Scroll the panel content area (most likely scrollable container)
            try {
                WebElement panelContent = service.getWebDriverWait(10L, TimeUnit.SECONDS)
                        .until(driver -> {
                            try {
                                return driver.findElement(org.openqa.selenium.By.xpath("//div[contains(@class,'components-panel__content')]"));
                            } catch (Exception e) {
                                return null;
                            }
                        });
                if (panelContent != null) {
                    js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;", panelContent);
                    logger.info("Scrolled panel content to bottom.");
                    Thread.sleep(500);
                }
            } catch (Exception e) {
                logger.warning("Panel content scroll failed: " + e.getMessage());
            }

            // Strategy 2: Scroll the main container
            try {
                WebElement container = service.getWebDriver().findElement(
                        service.getLookupBy("SDP Tranche Details Container"));
                js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;", container);
                logger.info("Scrolled container to bottom.");
                Thread.sleep(500);
            } catch (Exception e) {
                logger.warning("Container scroll failed: " + e.getMessage());
            }

            // Strategy 3: Scroll window to bottom (fallback)
            try {
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                logger.info("Scrolled window to bottom.");
                Thread.sleep(500);
            } catch (Exception e) {
                logger.warning("Window scroll failed: " + e.getMessage());
            }

            // Strategy 4: Scroll to approve button directly using scrollIntoView (if button exists)
            try {
                WebElement approveButton = service.getWebDriverWait(5L, TimeUnit.SECONDS)
                        .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy("SDP Checker Approve Yes Button")));
                js.executeScript("arguments[0].scrollIntoView({behavior: 'auto', block: 'end', inline: 'nearest'});", approveButton);
                logger.info("Scrolled to approve button using scrollIntoView.");
                Thread.sleep(500);
            } catch (Exception e) {
                logger.info("Direct scroll to button skipped (button may not be loaded yet, will wait in next step): " + e.getMessage());
            }

        } catch (Exception e) {
            logger.warning("Scroll operation encountered issues: " + e.getMessage());
        }
    }


    /**
     * Verify approval success message (checks element text contains expected message)
     */
    @Then("^verify approve success message '(.+)'$")
    public void verifyApproveSuccessMessage(String expectedMessage) {
        WebElement messageElement = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy("SDP Checker Approval Success Message")));
        String actualMessage = messageElement.getText();
        Assert.assertTrue("Approval success message not found. Expected: " + expectedMessage + ", Actual: " + actualMessage,
                actualMessage.contains(expectedMessage));
        logger.info("Verified approval success message: " + expectedMessage);
    }

    /**
     * Verify tranche status in table matches expected value for stored tranche ID
     * Step pattern: Then verify tranche status is 'Open for Subscription' in table 'SDP Tranche List Table' for stored tranche
     */
    @Then("^verify tranche status is '(.+)' in table '(.+)' for stored tranche$")
    public void verifyTrancheStatusInTable(String expectedStatus, String tableElementKey) {
        // Read stored Tranche ID from Uploaded_Tranche.xlsx
        String storedTrancheId = "";
        String excelPath = "src/test/resources/data/SDPortal/Uploaded_Tranche.xlsx";
        java.io.File excelFile = new java.io.File(excelPath);

        if (!excelFile.exists()) {
            throw new RuntimeException("Uploaded_Tranche.xlsx not found at: " + excelPath);
        }

        try (java.io.FileInputStream fis = new java.io.FileInputStream(excelFile);
             org.apache.poi.xssf.usermodel.XSSFWorkbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook(fis)) {

            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);
            int lastRowNum = sheet.getLastRowNum();

            if (lastRowNum < 1) {
                throw new RuntimeException("Uploaded_Tranche.xlsx has no data rows");
            }

            // Find Tranche ID column
            org.apache.poi.ss.usermodel.Row headerRow = sheet.getRow(0);
            int trancheIdCol = -1;
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.getCell(i);
                if (cell != null && cell.toString().trim().equalsIgnoreCase("Tranche ID")) {
                    trancheIdCol = i;
                    break;
                }
            }

            // Get last row (most recent Tranche ID)
            for (int rowIdx = lastRowNum; rowIdx >= 1; rowIdx--) {
                org.apache.poi.ss.usermodel.Row row = sheet.getRow(rowIdx);
                if (row != null && trancheIdCol >= 0 && row.getCell(trancheIdCol) != null) {
                    org.apache.poi.ss.usermodel.DataFormatter formatter = new org.apache.poi.ss.usermodel.DataFormatter();
                    String cellValue = formatter.formatCellValue(row.getCell(trancheIdCol)).trim();
                    if (!cellValue.isEmpty()) {
                        storedTrancheId = cellValue;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to read Tranche ID from Uploaded_Tranche.xlsx: " + e.getMessage(), e);
        }

        if (storedTrancheId.isEmpty()) {
            throw new RuntimeException("No Tranche ID found in Uploaded_Tranche.xlsx");
        }

        logger.info("Verifying status for Tranche ID: " + storedTrancheId);

        // Find table and locate row with Tranche ID
        WebElement table = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy(tableElementKey)));

        // Scroll table container to ensure it's visible
        try {
            JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
            // Find scrollable container
            WebElement scrollableContainer = table.findElement(org.openqa.selenium.By.xpath("./ancestor::div[contains(@class,'scrollable-x')]"));
            if (scrollableContainer != null) {
                js.executeScript("arguments[0].scrollLeft = arguments[0].scrollWidth;", scrollableContainer);
                logger.info("Scrolled table container horizontally to show status column.");
                Thread.sleep(500);
            }
        } catch (Exception e) {
            logger.warning("Could not scroll table container: " + e.getMessage());
        }

        // Find header row to get column index for "Tranche Status"
        org.openqa.selenium.By headerRowBy = org.openqa.selenium.By.xpath(".//thead//tr[@role='row']");
        WebElement headerRow = table.findElement(headerRowBy);
        java.util.List<WebElement> headerCells = headerRow.findElements(org.openqa.selenium.By.xpath(".//th[@role='columnheader']"));

        int trancheIdColIdx = -1;
        int statusColIdx = -1;

        for (int i = 0; i < headerCells.size(); i++) {
            String headerText = headerCells.get(i).getText().trim();
            if (headerText.equalsIgnoreCase("Tranche ID")) {
                trancheIdColIdx = i + 1; // XPath is 1-based
            } else if (headerText.equalsIgnoreCase("Tranche Status")) {
                statusColIdx = i + 1; // XPath is 1-based
            }
        }

        if (trancheIdColIdx == -1) {
            throw new RuntimeException("Tranche ID column not found in table");
        }
        if (statusColIdx == -1) {
            throw new RuntimeException("Tranche Status column not found in table");
        }

        logger.info("Tranche ID column index: " + trancheIdColIdx + ", Status column index: " + statusColIdx);

        // Find data row with matching Tranche ID
        java.util.List<WebElement> dataRows = table.findElements(org.openqa.selenium.By.xpath(".//tbody//tr[@role='row' and contains(@class,'components-table__row')]"));

        WebElement matchingRow = null;
        for (WebElement row : dataRows) {
            try {
                WebElement trancheIdCell = row.findElement(org.openqa.selenium.By.xpath(".//td[@role='cell'][" + trancheIdColIdx + "]"));
                String cellText = trancheIdCell.getText().trim();
                if (cellText.contains(storedTrancheId)) {
                    matchingRow = row;
                    logger.info("Found matching row with Tranche ID: " + storedTrancheId);
                    break;
                }
            } catch (Exception e) {
                // Continue to next row
            }
        }

        if (matchingRow == null) {
            throw new RuntimeException("Row with Tranche ID '" + storedTrancheId + "' not found in table");
        }

        // Scroll to the matching row to ensure it's visible
        try {
            JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
            js.executeScript("arguments[0].scrollIntoView({behavior: 'auto', block: 'center', inline: 'nearest'});", matchingRow);
            logger.info("Scrolled to matching row with Tranche ID: " + storedTrancheId);
            Thread.sleep(500);
        } catch (Exception e) {
            logger.warning("Could not scroll to row: " + e.getMessage());
        }

        // Get status value from the row
        WebElement statusCell = matchingRow.findElement(org.openqa.selenium.By.xpath(".//td[@role='cell'][" + statusColIdx + "]"));

        // Scroll status cell into view if needed
        try {
            JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
            js.executeScript("arguments[0].scrollIntoView({behavior: 'auto', block: 'center', inline: 'center'});", statusCell);
            logger.info("Scrolled to status cell.");
            Thread.sleep(300);
        } catch (Exception e) {
            logger.warning("Could not scroll to status cell: " + e.getMessage());
        }

        String actualStatus = statusCell.getText().trim();

        logger.info("Expected status: '" + expectedStatus + "', Actual status: '" + actualStatus + "'");
        Assert.assertTrue("Tranche status mismatch. Expected: " + expectedStatus + ", Actual: " + actualStatus,
                actualStatus.equalsIgnoreCase(expectedStatus) || actualStatus.contains(expectedStatus));
        logger.info("Verified tranche status in table: " + expectedStatus);
    }

//    @When("^Click 'SDP View Tranche Enable Button'$")
//    public void clickEnableButton() {
//        By lookup = service.getLookupBy("SDP View Tranche Enable Button");
//        service.getWebDriverWait(15L, TimeUnit.SECONDS)
//                .until(org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable(lookup));
//        WebElement btn = service.getWebDriver().findElement(lookup);
//        try { btn.click(); }
//        catch (Exception e) {
//            ((org.openqa.selenium.JavascriptExecutor) service.getWebDriver()).executeScript("arguments[0].click();", btn);
//        }
//        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
//    }

//    @Then("^verify enable success message '(.+)'$")
//    public void verifyEnableSuccessMessage(String expectedFragment) {
//        By msgLookup = service.getLookupBy("SDP Enable Success Message");
//        service.getWebDriverWait(15L, TimeUnit.SECONDS)
//                .until(org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated(msgLookup));
//        String text = service.getWebDriver().findElement(msgLookup).getText().trim();
//        service.getScreenShooter().takeScreenshot(scenario);
//        Assert.assertTrue("Enable message missing expected text", text.contains(expectedFragment));
//        By okLookup = service.getLookupBy("SDP Enable Success OK Button");
//        if (!service.getWebDriver().findElements(okLookup).isEmpty()) {
//            WebElement ok = service.getWebDriver().findElement(okLookup);
//            try { ok.click(); } catch (Exception e) {
//                ((org.openqa.selenium.JavascriptExecutor) service.getWebDriver()).executeScript("arguments[0].click();", ok);
//            }
//        }
//        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
//    }

    @Then("^verify tranche checkbox is checked for stored TrancheID in column '(.*)'$")
    public void verifyEnableCheckboxForStoredTranche() {
        Object stored = scenario.getAttribute("TRANCHE_ID");
        Assert.assertNotNull("TRANCHE_ID missing (precondition must run)", stored);
        String trancheId = stored.toString().trim();

        By tableLookup = service.getLookupBy("SDP Tranche List Table");
        service.getWebDriverWait(10L, TimeUnit.SECONDS)
                .until(org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated(tableLookup));
        WebElement table = service.getWebDriver().findElement(tableLookup);

        WebElement row = table.findElement(By.xpath(".//tr[.//mark[text()='" + trancheId + "'] or .//td[contains(.,'" + trancheId + "')]]"));
        WebElement checkboxContainer = row.findElement(By.xpath(".//td[1]//div[contains(@class,'components-check-box__container')]"));

        String aria = checkboxContainer.getAttribute("aria-checked");
        boolean checked = "true".equalsIgnoreCase(aria);
        if (!checked) {
            String classes = checkboxContainer.getAttribute("class");
            checked = classes != null && classes.contains("components-check-box__choices--checked");
        }

        service.getScreenShooter().takeScreenshot(scenario);
        Assert.assertTrue("Expected Enable-for-Mobile checkbox to be checked for tranche: " + trancheId, checked);
    }

    @Then("^verify tranche checkbox is '(.+)' is having value (.+) in table '(.+)' for stored tranche$")
    public void verifyTrancheCheckboxValueInTable(String checkboxHeader, String checkboxValueXPath, String tableElementKey) {
        // Read stored Tranche ID from Uploaded_Tranche.xlsx
        String storedTrancheId = "";
        String excelPath = "src/test/resources/data/SDPortal/Uploaded_Tranche.xlsx";
        java.io.File excelFile = new java.io.File(excelPath);

        if (!excelFile.exists()) {
            throw new RuntimeException("Uploaded_Tranche.xlsx not found at: " + excelPath);
        }

        try (java.io.FileInputStream fis = new java.io.FileInputStream(excelFile);
             org.apache.poi.xssf.usermodel.XSSFWorkbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook(fis)) {

            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);
            int lastRowNum = sheet.getLastRowNum();

            if (lastRowNum < 1) {
                throw new RuntimeException("Uploaded_Tranche.xlsx has no data rows");
            }

            // Find Tranche ID column
            org.apache.poi.ss.usermodel.Row headerRow = sheet.getRow(0);
            int trancheIdCol = -1;
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.getCell(i);
                if (cell != null && cell.toString().trim().equalsIgnoreCase("Tranche ID")) {
                    trancheIdCol = i;
                    break;
                }
            }

            // Get last row (most recent Tranche ID)
            for (int rowIdx = lastRowNum; rowIdx >= 1; rowIdx--) {
                org.apache.poi.ss.usermodel.Row row = sheet.getRow(rowIdx);
                if (row != null && trancheIdCol >= 0 && row.getCell(trancheIdCol) != null) {
                    org.apache.poi.ss.usermodel.DataFormatter formatter = new org.apache.poi.ss.usermodel.DataFormatter();
                    String cellValue = formatter.formatCellValue(row.getCell(trancheIdCol)).trim();
                    if (!cellValue.isEmpty()) {
                        storedTrancheId = cellValue;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to read Tranche ID from Uploaded_Tranche.xlsx: " + e.getMessage(), e);
        }

        if (storedTrancheId.isEmpty()) {
            throw new RuntimeException("No Tranche ID found in Uploaded_Tranche.xlsx");
        }

        logger.info("Verifying checkbox value for Tranche ID: " + storedTrancheId);

        // Find table and locate row with Tranche ID
        WebElement table = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy(tableElementKey)));

        // Find header row to get column index for "Enable for Mobile?"
        org.openqa.selenium.By headerRowBy = org.openqa.selenium.By.xpath(".//thead//tr[@role='row']");
        WebElement headerRow = table.findElement(headerRowBy);
        java.util.List<WebElement> headerCells = headerRow.findElements(org.openqa.selenium.By.xpath(".//th[@role='columnheader']"));

        int trancheIdColIdx = -1;
        int checkboxColIdx = -1;

        for (int i = 0; i < headerCells.size(); i++) {
            String headerText = headerCells.get(i).getText().trim();
            if (headerText.equalsIgnoreCase("Tranche ID")) {
                trancheIdColIdx = i + 1; // XPath is 1-based
            } else if (headerText.equalsIgnoreCase("Enable for Mobile?")) {
                checkboxColIdx = i + 1; // XPath is 1-based
            }
        }

        if (trancheIdColIdx == -1) {
            throw new RuntimeException("Tranche ID column not found in table");
        }
        if (checkboxColIdx == -1) {
            throw new RuntimeException("Enable for Mobile? column not found in table");
        }

        logger.info("Tranche ID column index: " + trancheIdColIdx + ", Checkbox column index: " + checkboxColIdx);

        // Find data row with matching Tranche ID
        java.util.List<WebElement> dataRows = table.findElements(org.openqa.selenium.By.xpath(".//tbody//tr[@role='row' and contains(@class,'components-table__row')]"));

        WebElement matchingRow = null;
        for (WebElement row : dataRows) {
            try {
                WebElement trancheIdCell = row.findElement(org.openqa.selenium.By.xpath(".//td[@role='cell'][" + trancheIdColIdx + "]"));
                String cellText = trancheIdCell.getText().trim();
                if (cellText.contains(storedTrancheId)) {
                    matchingRow = row;
                    logger.info("Found matching row with Tranche ID: " + storedTrancheId);
                    break;
                }
            } catch (Exception e) {
                // Continue to next row
            }
        }

        if (matchingRow == null) {
            throw new RuntimeException("Row with Tranche ID '" + storedTrancheId + "' not found in table");
        }

        // Get checkbox value from the row
        WebElement checkboxCell = matchingRow.findElement(org.openqa.selenium.By.xpath(".//td[@role='cell'][" + checkboxColIdx + "]//div[@role='checkbox']"));

        String actualCheckboxValue = checkboxCell.getAttribute("aria-checked").trim();

        logger.info("Expected checkbox value: 'true', Actual checkbox value: '" + actualCheckboxValue + "'");
        Assert.assertTrue("Checkbox value mismatch. Expected: true, Actual: " + actualCheckboxValue,
                actualCheckboxValue.equalsIgnoreCase("true"));
        logger.info("Verified tranche checkbox value in table: true");
    }


    /**
     * Verify approval success message (checks element text contains expected message)
     */
    @Then("^verify enable success message '(.+)'$")
    public void verifyEnableSuccessMessage(String expectedMessage) {
        WebElement messageElement = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy("SDP Enable Success Message")));
        String actualMessage = messageElement.getText();
        Assert.assertTrue("Enable success message not found. Expected: " + expectedMessage + ", Actual: " + actualMessage,
                actualMessage.contains(expectedMessage));
        logger.info("Verified Enable success message: " + expectedMessage);
    }

    /**
     * Scroll to the top of the page to make the specified element visible.
     * Uses JavaScript to scroll the window to the top.
     * Step pattern: And scroll to top of the page to locate element 'element'
     */
    @And("^scroll to top of the page to locate element '(.+)'$")
    public void scrollToTopOfPageToLocateElement(@Transform(LookupByTransformer.class) By element) {
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();

        try {
            // Scroll the window to the top
            js.executeScript("window.scrollTo(0, 0);");
            logger.info("Scrolled window to top.");

            // Wait for a short time to ensure the scroll action is completed
            Thread.sleep(500);

            // Verify that the element is now visible
            WebElement webElement = service.getWebDriverWait(10L, TimeUnit.SECONDS)
                    .until(ExpectedConditions.visibilityOfElementLocated(element));
            if (webElement != null) {
                logger.info("Element is now visible.");
            } else {
                logger.warning("Element is not visible after scrolling.");
            }

        } catch (Exception e) {
            logger.warning("Scroll to top operation encountered issues: " + e.getMessage());
        }
    }
}
