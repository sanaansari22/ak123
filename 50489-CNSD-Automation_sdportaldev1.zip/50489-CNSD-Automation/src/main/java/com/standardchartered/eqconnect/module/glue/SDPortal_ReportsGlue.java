package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.CalendarUtils;
import com.standardchartered.eqconnect.module.support.DownloadUtils;
import com.standardchartered.eqconnect.module.support.NetworkCsvCaptureUtils;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.core.util.SeleniumNavigationUtil;
import cucumber.api.java.After;
import helpers.SDTranchUploadHelper;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import static com.standardchartered.genie.module.selenium.core.util.SeleniumNavigationUtil.refreshWebPage;
import static com.standardchartered.genie.module.selenium.core.util.SeleniumNavigationUtil.setBaseUrl;

public class SDPortal_ReportsGlue {

    private static final Logger logger = Logger.getLogger(SDPortal_ReportsGlue.class.getName());
    private static final Path DEST_FOLDER = Paths.get("./data/SDPortal/SDPortalReports");

    private GenieScenario scenario;
    private SeleniumService service;


    // ---------------------------------------------------------
    // Before Hook
    // ---------------------------------------------------------
    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        logger.info("Initializing scenario...");
        try {
            this.scenario = (GenieScenario) cucumberScenario;
            this.service = this.scenario.getRuntime().getAttribute("seleniumService");
            this.service = this.scenario.getRuntime().getAttribute("seleniumService");

            logger.info("SeleniumService initialized successfully.");
        } catch (Exception e) {
            logger.severe("Error initializing Selenium service: " + e.getMessage());
            throw e;
        }
    }

    // ---------------------------------------------------------
    // Select Report Type
    // ---------------------------------------------------------
    @And("^select report type '(.+)'$")
    public void selectReportType(String reportType) throws InterruptedException {
        logger.info("Selecting report type: " + reportType);

        try {
            WebElement reportTypeDropDown = service.getWebDriverWait(5L, TimeUnit.SECONDS)
                    .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy("Report Type Dropdown")));

            logger.info("Dropdown located. Clicking...");
            reportTypeDropDown.click();

            Thread.sleep(1000); // allow list to expand

            WebElement reportOption = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                    .until(ExpectedConditions.visibilityOfElementLocated(service.getLookupBy(reportType)));

            logger.info("Report type option found: " + reportOption.getText());
            reportOption.click();

            logger.info("Report type '" + reportType + "' selected successfully.");
            Thread.sleep(1000);

        } catch (Exception e) {
            logger.severe("Failed to select report type: " + e.getMessage());
            throw new RuntimeException("Error selecting report type: " + reportType, e);
        }
    }

    // ---------------------------------------------------------
    // Select Dates
    // ---------------------------------------------------------
    @And("^select from date '(.+)' and to date '(.+)'$")
    public void selectDates(String fromDate, String toDate) {
        logger.info("Selecting dates: From = " + fromDate + ", To = " + toDate);
        WebDriver driver = service.getWebDriver();

        By fromPicker = service.getLookupBy("Report from date picker");
        By toPicker = service.getLookupBy("Report to date picker");

        try {
            WebDriverWait wait = service.getWebDriverWait(10L, TimeUnit.SECONDS);
            wait.until(ExpectedConditions.elementToBeClickable(fromPicker));
            wait.until(ExpectedConditions.elementToBeClickable(toPicker));

            CalendarUtils calendar = new CalendarUtils(driver, 10);
            calendar.selectDateUsingIcon(fromPicker, fromDate);
            calendar.selectDateUsingIcon(toPicker, toDate);

            logger.info("Dates selected successfully.");

        } catch (Exception e) {
            logger.severe("Error selecting dates: " + e.getMessage());
            throw new RuntimeException("Date selection failed", e);
        }
    }

    // ---------------------------------------------------------
    // Click Generate Report
    // ---------------------------------------------------------
    @Then("^Maker click Generate Report and save network response for '(.+)'$")
    public void generateReport(String reportType) throws IOException {
        logger.info("Clicking on 'Retrieve Report' button...");

        try {
            WebElement retrieveReportButton = service.getWebDriverWait(5L, TimeUnit.SECONDS)
                    .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy("Retreive Report button")));

            retrieveReportButton.click();
            logger.info("Retrieve Report button clicked.");

            // Tracking start of download
            waitForDownloadToStart();
            logger.info("Download process detected.");

        } catch (Exception e) {
            logger.severe("Failed to generate report: " + e.getMessage());
            throw new RuntimeException("Generate Report button action failed", e);
        }

       /* Path destFolder = Paths.get("./data/SDPortal/SDPortalNetworkReport");
        String urlPartial = "/report/reports"; // match CSV download URL

        try {
            int status = NetworkCsvCaptureUtils.captureCsvFromNetwork(
                    service.getWebDriver(),
                    urlPartial,
                    destFolder,
                    reportType,
                    120_000 // 120 seconds timeout
            );

            if (status != 200) {
                throw new RuntimeException("CSV download HTTP status code not 200: " + status);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to capture CSV network response", e);
        }*/
    }

    // ---------------------------------------------------------
    // Save Downloaded File
    // ---------------------------------------------------------
    @Then("^Save the captured file$")
    public void captureGeneratedReport() throws InterruptedException, IOException {
        Path destinationFolder = Paths.get("./data/SDPortal/SDPortalReports");
        try {
            logger.info("Waiting for CSV report to finish downloading...");

            // Wait for CSV download and move it to destination folder
            Path downloadedCsv = DownloadUtils.waitForCsvDownloadAndMove(120, destinationFolder);

            logger.info("CSV report successfully downloaded and moved: " + downloadedCsv.toAbsolutePath());

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.severe("Thread interrupted while waiting for CSV download: " + e.getMessage());
            throw new RuntimeException("Thread interrupted while waiting for CSV download", e);
        } catch (Exception e) {
            logger.severe(" Error saving downloaded CSV report: " + e.getMessage());
            throw new RuntimeException("Failed to capture CSV report", e);
        }
    }

    // ---------------------------------------------------------
    // Verify Folder Contains File
    // ---------------------------------------------------------
    @Then("the report file should be present in the destination folder")
    public void reportShouldBePresent() {
        logger.info("Validating destination folder...");

        if (!Files.exists(DEST_FOLDER) || !Files.isDirectory(DEST_FOLDER)) {
            logger.severe("Destination folder missing: " + DEST_FOLDER);
            throw new IllegalStateException("Destination folder missing: " + DEST_FOLDER);
        }

        logger.info("Destination folder exists: " + DEST_FOLDER);
    }

    // ---------------------------------------------------------
    // Download Detection Helper (with logging)
    // ---------------------------------------------------------
    private void waitForDownloadToStart() {
        logger.info("Checking for download start in default Downloads folder...");

        long start = System.currentTimeMillis();
        File downloads = new File(System.getProperty("user.home") + "/Downloads");

        while (System.currentTimeMillis() - start < 5000) {
            File[] list = downloads.listFiles((dir, name) -> name.toLowerCase().endsWith(".xlsx"));
            if (list != null && list.length > 0) {
                logger.info("Download started: " + list[0].getName());
                return;
            }

            try {
                Thread.sleep(200);
            } catch (InterruptedException ignored) {
            }
        }

        logger.warning("Download did NOT start within 5 seconds.");
    }

    // ---------------------------------------------------------
    @And("^Compare the response$")
    public void compareReport() {
        logger.info("Compare report placeholder method.");
    }


    @After("@selenium")
    public void afterScenario(Scenario cucumberScenario) {
        logger.info("Entering @After hook for scenario: " + cucumberScenario.getName());

        try {
            if (service == null || service.getWebDriver() == null) {
                logger.warning("SeleniumService or WebDriver is null in After hook. Skipping cleanup.");
                return;
            }

            WebDriver driver = service.getWebDriver();

            // ------------------------------
            // 1) Capture screenshot on failure
            // ------------------------------
            if (cucumberScenario.isFailed()) {
                try {
                    byte[] screenshot = ((org.openqa.selenium.TakesScreenshot) driver)
                            .getScreenshotAs(org.openqa.selenium.OutputType.BYTES);
                    cucumberScenario.embed(screenshot, "image/png");
                    logger.info("Screenshot captured and embedded due to failure.");
                } catch (Exception e) {
                    logger.warning("Unable to capture screenshot: " + e.getMessage());
                }
            }

            // ------------------------------
            // 2) Cleanup cookies
            // ------------------------------
            try {
                driver.manage().deleteAllCookies();
                logger.info("Cookies cleared.");
            } catch (Exception e) {
                logger.warning("Unable to clear cookies: " + e.getMessage());
            }


        } catch (Exception ex) {
            logger.severe("Unexpected error in @After scenario hook: " + ex.getMessage());
        }
    }

    @And("^refresh the webpage for report$")
    public void refreshWebpage() {
    refreshWebPage(service.getWebDriver());
//        setBaseUrl(service.getWebDriver(),"")
        try {
            // Wait for the page to load and the button to be present
            WebDriverWait wait = new WebDriverWait(service.getWebDriver(), Duration.ofMillis(30));
            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='components-alert-modal__button']//button[contains(text(),'CLOSE')]")));

            // Click the close button
            closeButton.click();
        } catch (Exception e) {
            // Handle the case where the alert popup does not appear
            System.out.println("Alert popup did not appear, proceeding without clicking the close button.");
        }
//        service.getWebDriver().quit();
    }


}
