package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.GenieGenericsService;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.core.util.SeleniumInteractionUtil;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import static com.standardchartered.eqconnect.module.glue.genericGlue.waitfor;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;


public class eqccnGlue {

    private GenieScenario scenario;
    private SeleniumService service;
    private GenieGenericsService GenieService;

    @Before("@selenium")
    public void beforeScenario(Scenario scenario) {
        this.scenario = (GenieScenario) scenario;
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");
    }

    @And("^Validate whether best price is displayed on top of Quote History Blotter '(.+)' '(.+)'$")
    public void validateRFQQuoteHistoryBlotterBestPriceIsDisplayedOnTop(String topPriceLocator,String priceColumnLocator) {

        String solveForText = service.getWebDriver().findElement(service.getLookupBy("RFQ Blotter Solve For")).getText();

        if( (solveForText.contains("Spread")) || ( solveForText.contains("KO % of Initial") ) || (solveForText.contains("Strike")) || ( solveForText.contains("KI % of Initial") )) {
            String topPrice = service.getWebDriver().findElement(service.getLookupBy(topPriceLocator)).getText();

            for(WebElement pricer : service.getWebDriver().findElements(service.getLookupBy(priceColumnLocator))){
                if(pricer.getText().isEmpty())
                    continue;
                System.out.println("solveForText : " + solveForText + "\nTop price is : "+topPrice);
                System.out.println("Price from the column : "+pricer.getText());
                if (Float.parseFloat(pricer.getText()) < Float.parseFloat(topPrice)){
                    Assert.fail("Top price is not the best price for solveForText :" +solveForText + " Top price is : " +topPrice + " Price from the column : " +pricer.getText());
                    break;
                }
            }
        } else if( (solveForText.contains("KO Coupon (%)") ) || (solveForText.contains("No KO Coupon")) || (solveForText.contains("Coupon (%) p.a."))){
            String topPrice = service.getWebDriver().findElement(service.getLookupBy(topPriceLocator)).getText();
            for(WebElement pricer : service.getWebDriver().findElements(service.getLookupBy(priceColumnLocator))){
                if(pricer.getText().isEmpty())
                    continue;
                System.out.println("solveForText : " + solveForText + "\nTop price is : "+topPrice);
                System.out.println("Price from the column : "+pricer.getText());
                if (Float.parseFloat(pricer.getText()) > Float.parseFloat(topPrice)){
                    Assert.fail("Top price is not the best price for solveForText :" +solveForText + " Top price is : " +topPrice + " Price from the column : " +pricer.getText());
                    break;
                }
            }
        } else {
            String topPrice = service.getWebDriver().findElement(service.getLookupBy(topPriceLocator)).getText();
            for(WebElement pricer : service.getWebDriver().findElements(service.getLookupBy(priceColumnLocator))){
                if(pricer.getText().isEmpty())
                    continue;
                System.out.println("Top price is : "+topPrice);
                System.out.println("Price from the column : "+pricer.getText());
                if (Float.parseFloat(pricer.getText()) > Float.parseFloat(topPrice)){
                    Assert.fail("Top price is not the best price");
                    break;
                }
            }
        }
    }

    @And("^Click place order link in RM Workstation for the Tranche '(.+)'$")
    public void searchTrancheAndClickPlaceOrderLink(String TrancheID) {

        String TrancheNum = scenario.getAttribute(TrancheID).toString().trim();
        List<WebElement> productList = service.getWebDriver().findElements(service.getLookupBy("Product label in RM Workstation"));
        int productCount = productList.size();

        if( productList.isEmpty()){
            Assert.fail("Products not Available in the RM Workstation");
            return;
        }
        for(WebElement product : productList) {

            String ProdDescription = product.getText();

            if (productCount>0) {

                if (ProdDescription.contains(TrancheNum)) {

                    // Clicking place order link for the respective tranche ID  and switch to frame
                    service.getWebDriver().findElement(By.xpath("//*[contains(@id,'ctl00_MainContent_dlProductPriceDetails')]//*[@class='lblProduct' and contains(text()," + TrancheNum + ")]/following::div[@id='divneworder'][1]")).click();
                    waitfor(5);
                    SeleniumInteractionUtil.findAndSwitchToFrame(this.service.getWebDriver(), By.xpath("//iframe[contains(@src," + TrancheNum + ")]"));
                    waitfor(3);
                    break;
                }
                productCount--;

                if (productCount==0) {
                    System.out.println("Unable to click place order link as the product with the Tranche ID " + TrancheNum + " is not available in the RM Workstation");
                    Assert.fail("Unable to click place order link as the product with the Tranche ID " + TrancheNum + " is not available in the RM Workstation");
                }
            }
        }
    }

    @And("^Click indicative customer termsheet link in RM Workstation for the Tranche '(.+)' (.+) '(.+)'$")
    public void searchTrancheAndClickIndicativeCustomerTermSheet(String TrancheID, String TermSheetLanguageID,String fileName) {

        String TrancheNum = scenario.getAttribute(TrancheID).toString().trim();
        List<WebElement> productList = service.getWebDriver().findElements(service.getLookupBy("Product label in RM Workstation"));
        int productCount = productList.size();

        if (productList.isEmpty()) {
            Assert.fail("Products not Available in the RM Workstation");
            return;
        }
        for(WebElement product : productList) {
            String productDescription = product.getText();
            if (productCount>0) {
                if (productDescription.contains(TrancheNum)) {
                    // Clicking place order link for the respective tranche ID  and switch to frame
                    service.getWebDriver().findElement(By.xpath("//*[contains(@id,'ctl00_MainContent_dlProductPriceDetails')]//*[@class='lblProduct' and contains(text()," + TrancheNum + ")]/following::div[@id=" + TermSheetLanguageID + "][1]")).click();
                    waitfor(8);
                    String originalWindowID = service.getWebDriver().getWindowHandle();
                    Set<String> winHandles = service.getWebDriver().getWindowHandles();
                    System.out.println("original window handle ID : " + originalWindowID);

                    System.out.println("All window handles ID's : " + winHandles);
                    for(String s:winHandles) {
                        System.out.println("Window Handle ID : " + s);

                        if (!s.equals(originalWindowID)) {
                            service.getWebDriver().switchTo().window(s);
                            waitfor(1);
                            String currentPageURL = service.getWebDriver().getCurrentUrl().toLowerCase();
                            System.out.println("Page URL after switching to new tab : " + currentPageURL);
                            if (currentPageURL.contains(fileName.toLowerCase())) {
                                System.out.println("Current page URL contains the expected file name : " + fileName);
                                service.getWebDriver().close();
                                waitfor(1);
                                break;
                            }
                        }
                    }
                    break;
                }
                productCount--;

                if (productCount==0) {
                    System.out.println("Unable to click the Indicative Customer TermSheet link as the product with the Tranche ID " + TrancheNum + " is not available in the RM Workstation");
                    Assert.fail("Unable to click the Indicative Customer TermSheet link as the product with the Tranche ID " + TrancheNum + " is not available in the RM Workstation");
                }
            }
        }
    }

    @And("^enter the value in the fixing rate field '(.+)'$")
    public void enterFixingRateValue(String element) {

        try {
            WebElement fixingRateField = service.getWebDriver().findElement(service.getLookupBy(element));
            String fixingRateCurrentValue = service.getWebDriver().findElement(service.getLookupBy("Fixing Rate Current Value")).getText();

            if ( !(fixingRateCurrentValue.isEmpty())) {
                waitfor(1);
                fixingRateField.sendKeys(fixingRateCurrentValue);
                waitfor(2);

            } else {
                fixingRateField.sendKeys("7.5");
                waitfor(2);
            }
        } catch (Exception e) {
            System.out.print("Text field is not displayed on the page --- Exception message : " + e.getMessage());
        }
    }

    @And("^enter the value in the filled notional field '(.+)'$")
    public void enterExecutionNotionalValue(String filledStatusValue) {

        try {
            WebElement filledNotionalField = service.getWebDriver().findElement(service.getLookupBy("Filled Notional Field"));
            String orderNotionalValue = service.getWebDriver().findElement(service.getLookupBy("Order Notional Field")).getAttribute("value");
            String filledNotionalValue = filledNotionalField.getAttribute("value");

            if ( (filledStatusValue.equalsIgnoreCase("filled")) && ( (filledNotionalValue==null) || (filledNotionalValue.isEmpty()))) {

                waitfor(1);
                filledNotionalField.sendKeys(orderNotionalValue);
                waitfor(2);
            } else if ( (filledStatusValue.equalsIgnoreCase("partiallyFilled")) && ( (filledNotionalValue==null) || (filledNotionalValue.isEmpty()))){
                orderNotionalValue = orderNotionalValue.replace(",","");
                double orderNotionalIntegerValue =  (Double.parseDouble(orderNotionalValue))/2;
                filledNotionalField.sendKeys(String.valueOf(orderNotionalIntegerValue));
                waitfor(2);
            }
        } catch (Exception e) {
            System.out.print("Text field is not displayed on the page --- Exception message : " + e.getMessage());
        }
    }

    @And("^set client cutoff time '(.+)'$")
    public void setClientCutOffTime(int clientCutOffTime) {

        // Setting Client cut off time
        updateDateAndTimeAndSave(clientCutOffTime,"clientCutOffExpectedDate","clientCutOffExpectedHour","clientCutOffExpectedMinutes","clientCutOffExpectedHourFormat","Client Order CutOff Date Picker");
    }


    @And("^set cooling period end date and time '(.+)'$")
    public void setCoolingPeriodEndTime(int coolingPeriodEndTime) {

        // Setting cooling period end time
        updateDateAndTimeAndSave(coolingPeriodEndTime,"coolingPeriodExpectedDate","coolingPeriodExpectedHour","coolingPeriodExpectedMinutes","coolingPeriodExpectedHourFormat","Cooling Period End Date Picker");
    }

    @And("^set window period end date and time '(.+)'$")
    public void setWindowPeriodEndTime(int windowPeriodEndTime) {

        // Setting Window period end time
        updateDateAndTimeAndSave(windowPeriodEndTime,"windowPeriodExpectedDate","windowPeriodExpectedHour","windowPeriodExpectedMinutes","windowPeriodExpectedHourFormat","Window Period End Date Picker");
    }

    public void updateDateAndTimeAndSave(int timeInMinutes,String expectedDate,String expectedHour,String expectedMinutes,String expectedHourFormat,String datePickerElement) {

        Calendar calendarInstance = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd:hh:mm:a");

        dateFormat.setTimeZone( TimeZone.getTimeZone("Asia/Singapore"));

        String currentTime = dateFormat.format(calendarInstance.getTime());
        calendarInstance.add(Calendar.MINUTE,timeInMinutes);
        String newTime = dateFormat.format(calendarInstance.getTime());
        String[] dateAndTime = newTime.split(":");

        //dayOfMonth
        String date = dateAndTime[0].split("-")[2];
        String month = dateAndTime[0].split("-")[1];

        String hour = dateAndTime[1];
        String minutes = dateAndTime[2];
        String hourFormat = dateAndTime[3];

        scenario.setAttribute(expectedDate, date);
        scenario.setAttribute(expectedHour, hour);
        scenario.setAttribute(expectedMinutes, minutes);
        scenario.setAttribute(expectedHourFormat, hourFormat);

        setDateAndTime(datePickerElement,month,hour,minutes,hourFormat,date);
    }

    public void setDateAndTime(String ele,String month,String hour,String minutes,String hourFormat,String date) {

        service.getWebDriver().findElement(service.getLookupBy(ele)).click();
        waitfor(3);

        WebElement monthSelector = service.getWebDriver().findElement(service.getLookupBy("Month Selector in Calendar"));
        Select dropdownElement = new Select(monthSelector);

        if ( !( dropdownElement.getFirstSelectedOption().getText().equalsIgnoreCase(month)) ) {
            dropdownElement.selectByVisibleText(month);
            waitfor(2);
        }

        WebElement hourEle = service.getWebDriver().findElement(service.getLookupBy("Enter Hour in DatePicker Calendar"));

        hourEle.clear();
        waitfor(1);

        hourEle.sendKeys(hour);
        waitfor(2);

        WebElement minutesEle = service.getWebDriver().findElement(service.getLookupBy("Enter Minutes in DatePicker Calendar"));

        minutesEle.clear();
        waitfor(1);

        minutesEle.sendKeys(minutes);
        waitfor(2);

        WebElement hourFormatEle = service.getWebDriver().findElement(service.getLookupBy("Enter HourFormat in DatePicker Calendar"));

        hourFormatEle.clear();
        waitfor(1);

        hourFormatEle.sendKeys(hourFormat);
        waitfor(2);

        service.getWebDriver().findElement(By.xpath("//*[not(contains(@class,'ui-datepicker-other-month'))]/a[@data-date="+date+"]")).click();
        waitfor(4);
    }
}
