package com.standardchartered.eqconnect.module.support;

import org.openqa.selenium.WebDriver;

import java.time.Duration;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CalendarUtils {

    private WebDriver driver;
    private WebDriverWait wait;

    public CalendarUtils(WebDriver driver, long timeoutSeconds) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
    }

    /**
     * Selects a date by clicking the date-picker icon and using next/prev arrows.
     * @param dateIcon locator for the calendar icon/button (click this, not the input)
     * @param dateToSelect target date in format "dd-MM-yyyy" (e.g. "22-10-2015")
     */
    public void selectDateUsingIcon(By dateIcon, String dateToSelect) {
        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH);
        LocalDate targetDate = LocalDate.parse(dateToSelect, inputFmt);
        YearMonth targetYm = YearMonth.from(targetDate);

        // 1) click only the icon to open the calendar
        wait.until(ExpectedConditions.elementToBeClickable(dateIcon)).click();

        // 2) locators for typical jQuery UI datepicker elements (adjust if your HTML differs)
        By datepickerTitle = By.cssSelector(".components-calendar__date-title");    // text like "October 2015"
        By prevBtn = By.xpath("(//div[contains(@class,'components-calendar__container')]//th[contains(@class,'components-calendar__heading')]/*[local-name()='svg'])[1]");
        By nextBtn = By.xpath("(//div[contains(@class,'components-calendar__container')]//th[contains(@class,'components-calendar__heading')]/*[local-name()='svg'])[2]");
        By datepickerRoot = By.cssSelector(".components-calendar__container"); // may be multiple; the visible one is used via waits

        // wait for datepicker to show
        wait.until(ExpectedConditions.visibilityOfElementLocated(datepickerRoot));

        // 3) navigate to correct month/year
        DateTimeFormatter titleFmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH);

        // safety guard to avoid infinite loop (max months to move)
        int maxIterations = 120; // allow up to 10 years of navigation (adjust if needed)
        int iter = 0;

        while (iter++ < maxIterations) {
            // title text example: "October 2015"
            String titleText = wait.until(ExpectedConditions.visibilityOfElementLocated(datepickerTitle)).getText().trim();
            YearMonth displayedYm;
            try {
                displayedYm = YearMonth.parse(titleText, titleFmt);
            } catch (Exception e) {
                // If parsing fails, try to clean text (some datepickers have extra whitespace)
                titleText = titleText.replaceAll("\\s+", " ");
                displayedYm = YearMonth.parse(titleText, titleFmt);
            }

            if (displayedYm.equals(targetYm)) {
                break; // we're on desired month & year
            }

            if (displayedYm.isBefore(targetYm)) {
                // click next
                wait.until(ExpectedConditions.elementToBeClickable(nextBtn)).click();
            } else {
                // click prev
                wait.until(ExpectedConditions.elementToBeClickable(prevBtn)).click();
            }

            // small wait for calendar to update (visibilityOfElementLocated ensures it updates)
            wait.until(ExpectedConditions.visibilityOfElementLocated(datepickerTitle));
        }

        if (iter >= maxIterations) {
            throw new RuntimeException("Could not reach target month/year: " + targetYm);
        }

        // 4) click the day inside the visible datepicker
        String dayStr = String.valueOf(targetDate.getDayOfMonth());
        // Common structure: <a>day</a> inside the table. Restrict to the visible datepicker to avoid other pickers.
        By dayLocator = By.xpath("//table[contains(@class,'components-calendar__calendar-container')]//span[contains(@class,'components-calendar__day-span-value') and normalize-space(.)='"+dayStr+"']");

        // Some datepickers render day as <td><a> or <td><span> etc. Fallback:
        if (driver.findElements(dayLocator).isEmpty()) {
            // fallback xpath: any clickable day text in visible calendar
            dayLocator = By.xpath("//div[contains(@class,'ui-datepicker') and contains(@style,'display: block')]//td[normalize-space()='" + dayStr + "']//a | //div[contains(@class,'ui-datepicker') and contains(@style,'display: block')]//a[text()='" + dayStr + "']");
        }

        WebElement dayEl = wait.until(ExpectedConditions.elementToBeClickable(dayLocator));
        dayEl.click();

        // optionally: wait until calendar disappears or input value updated
        // wait.until(ExpectedConditions.invisibilityOfElementLocated(datepickerRoot));
    }
}
