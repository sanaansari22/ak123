package com.standardchartered.eqconnect.module.support;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class DownloadUtils {

    private static final Logger logger = Logger.getLogger(DownloadUtils.class.getName());

    /**
     * Waits for a new CSV file to appear in known download directories.
     * Waits until its size stabilizes (download complete), then moves it to the destination folder.
     *
     * @param timeoutSeconds Total wait time before giving up
     * @param destinationFolder Folder to move the downloaded CSV
     * @return The downloaded CSV file path
     * @throws InterruptedException
     * @throws IOException
     */
    public static Path waitForCsvDownloadAndMove(int timeoutSeconds, Path destinationFolder)
            throws InterruptedException, IOException {

        logger.info("🔍 Waiting for CSV download. Timeout: " + timeoutSeconds + " seconds");

        long start = System.currentTimeMillis();
        long timeoutMs = timeoutSeconds * 1000L;

        // Directories to monitor
        List<Path> candidateDirs = Arrays.asList(
                        Paths.get(System.getProperty("user.home"), "Downloads"),
                        Paths.get(System.getProperty("user.dir")),
                        Paths.get("/tmp")
                ).stream()
                .filter(Files::exists)
                .collect(Collectors.toList());

        logger.info("Monitoring directories: " + candidateDirs);

        // Initial snapshot before download starts
        Map<Path, Long> initialSnapshot = snapshotCsv(candidateDirs);
        logger.info("📸 Initial CSV snapshot: " + initialSnapshot.keySet());

        Path downloadedFile = null;

        while (System.currentTimeMillis() - start < timeoutMs) {

            Map<Path, Long> currentSnapshot = snapshotCsv(candidateDirs);

            Optional<Path> newest = currentSnapshot.entrySet().stream()
                    .filter(e -> {
                        Long init = initialSnapshot.get(e.getKey());
                        return init == null || e.getValue() > init; // new or modified
                    })
                    .map(Map.Entry::getKey)
                    .max(Comparator.comparingLong(p -> p.toFile().lastModified()));

            if (newest.isPresent()) {
                Path file = newest.get();
                logger.info("📄 New CSV detected: " + file);

                if (waitForStableSize(file, 5, 1000)) {
                    downloadedFile = file;
                    break;
                } else {
                    logger.warning("⚠ CSV file size not stable yet: " + file);
                }
            }

            Thread.sleep(1000);
        }

        if (downloadedFile == null) {
            throw new IllegalStateException("No CSV file downloaded within timeout");
        }

        // Ensure destination folder exists
        if (!Files.exists(destinationFolder)) {
            Files.createDirectories(destinationFolder);
        }

        Path destFile = destinationFolder.resolve(downloadedFile.getFileName());
        Files.move(downloadedFile, destFile, StandardCopyOption.REPLACE_EXISTING);

        logger.info("CSV download moved to: " + destFile.toAbsolutePath());
        return destFile;
    }

    /**
     * Take a snapshot of all CSV files in the given directories
     */
    private static Map<Path, Long> snapshotCsv(List<Path> dirs) {
        Map<Path, Long> map = new HashMap<>();
        for (Path dir : dirs) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.csv")) {
                for (Path p : stream) {
                    if (Files.isRegularFile(p)) {
                        map.put(p, p.toFile().lastModified());
                    }
                }
            } catch (Exception e) {
                logger.warning("⚠ Failed to read directory: " + dir + " - " + e.getMessage());
            }
        }
        return map;
    }

    /**
     * Waits until file size is stable for given number of checks
     */
    private static boolean waitForStableSize(Path file, int checks, long intervalMs) throws InterruptedException {
        try {
            long previousSize = Files.size(file);

            for (int i = 0; i < checks; i++) {
                Thread.sleep(intervalMs);
                long newSize = Files.size(file);
                if (newSize != previousSize) {
                    previousSize = newSize;
                    i = -1; // reset counter
                }
            }
            return true;
        } catch (Exception e) {
            logger.warning("Error checking file size for " + file + " - " + e.getMessage());
            return false;
        }
    }
}
