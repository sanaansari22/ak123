package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import helpers.SDTranchUploadHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import com.standardchartered.eqconnect.module.support.excelDriver;
import static org.junit.Assert.*;

import java.nio.file.Paths;
import java.util.logging.Logger;

/**
 * SDPortal_TermUploadGlue
 *
 * Glue class to automate Termsheet Upload on SD Portal (TC 5578601).
 *
 * Important notes:
 * - Uses Genie runtime attribute "seleniumService" to get SeleniumService instance.
 * - Re-uses existing helper classes:
 *    - TrancheUploadHelper.uploadFile(WebElement input, String filePath)  <-- your existing method
 *    - ExcelDriver (or your Tranche storage utility) to read stored TrancheID and dates
 *
 * - All methods are commented to explain the intent & usage.
 */
public class SDPortal_TermsheetUploadGlue {

    private static final Logger logger = Logger.getLogger(SDPortal_TermsheetUploadGlue.class.getName());
    /**
     * GenieScenario: cast of cucumber Scenario so we can access Genie runtime attributes.
     * Holds runtime objects such as seleniumService and allows storing attributes for cross-scenario use.
     */
    private GenieScenario scenario;

    /**
     * SeleniumService: wrapper around WebDriver provided by Genie.
     * Use this for element lookups, waits and WebDriver access.
     */
    private SeleniumService service;

    /**
     * Page/helper object that does all file & Excel manipulation.
     * Note: the helper does NOT use WebDriver. It returns prepared file paths and saves IDs to Excel.
     */
    private SDTranchUploadHelper uploadHelper;
    private String windowPeriodStartDate;
    private String windowPeriodEndDate;
    private excelDriver excelDriver;
    private String storedWindowEnd;
    private String excelFileName; // actual sheet name


    // ---------------------------------------------------------------------
    // Before hook: runs before scenarios tagged @selenium
    // ---------------------------------------------------------------------
    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        // 1) Cast Cucumber Scenario to GenieScenario to access runtime attributes
        this.scenario = (GenieScenario) cucumberScenario;

        // 2) Retrieve the SeleniumService instance stored in Genie runtime
        //    The runtime key "seleniumService" is set by the framework when the Selenium module is started.
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");

        // 3) Instantiate the file-helper which will be used to prepare the Excel file
        //    The helper only does file/Excel work (no WebDriver calls).
        this.uploadHelper = new SDTranchUploadHelper();
        this.excelDriver = new excelDriver();


    }


    @When("^search tranche using stored TrancheID from file$")
    public void searchTrancheUsingStoredTranche() {
        assertService();

        // Read latest Tranche ID from Uploaded_Tranche.xlsx (last row = most recent)
        String excelPath = "src/test/resources/data/SDPortal/Uploaded_Tranche.xlsx";
        java.io.File excelFile = new java.io.File(excelPath);

        if (!excelFile.exists()) {
            throw new RuntimeException("Uploaded_Tranche.xlsx not found at: " + excelPath);
        }

        String storedTrancheId = "";
        String storedWindowStart = "";
        this.storedWindowEnd = "";

        try (java.io.FileInputStream fis = new java.io.FileInputStream(excelFile);
             org.apache.poi.xssf.usermodel.XSSFWorkbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook(fis)) {

            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);
            int lastRowNum = sheet.getLastRowNum();

            // Check if file has data rows (header is row 0, so need at least row 1)
            if (lastRowNum < 1) {
                throw new RuntimeException("Uploaded_Tranche.xlsx has no data rows (only header). Last row index: " + lastRowNum);
            }

            logger.info("Total rows in sheet: " + (lastRowNum + 1) + " (header + " + lastRowNum + " data rows)");

            // Find column indices by header (row 0)
            org.apache.poi.ss.usermodel.Row headerRow = sheet.getRow(0);
            int trancheIdCol = -1, windowStartCol = -1, windowEndCol = -1;

            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.getCell(i);
                if (cell != null) {
                    String headerValue = cell.toString().trim();
                    if (headerValue.equalsIgnoreCase("Tranche ID")) {
                        trancheIdCol = i;
                    } else if (headerValue.equalsIgnoreCase("Window Period Start Datetime")) {
                        windowStartCol = i;
                    } else if (headerValue.equalsIgnoreCase("Window Period End Datetime")) {
                        windowEndCol = i;
                    }
                }
            }

            logger.info("Column indices - Tranche ID: " + trancheIdCol +
                    ", Window Start: " + windowStartCol + ", Window End: " + windowEndCol);

            // Get LAST row (most recent Tranche ID) - iterate backwards to find last non-empty row
            org.apache.poi.ss.usermodel.Row lastRow = null;
            for (int rowIdx = lastRowNum; rowIdx >= 1; rowIdx--) {
                org.apache.poi.ss.usermodel.Row row = sheet.getRow(rowIdx);
                if (row != null) {
                    // Check if row has data in Tranche ID column
                    if (trancheIdCol >= 0 && row.getCell(trancheIdCol) != null) {
                        org.apache.poi.ss.usermodel.DataFormatter tempFormatter = new org.apache.poi.ss.usermodel.DataFormatter();
                        String cellValue = tempFormatter.formatCellValue(row.getCell(trancheIdCol)).trim();
                        if (!cellValue.isEmpty()) {
                            lastRow = row;
                            logger.info("Found last data row at index: " + rowIdx);
                            break;
                        }
                    }
                }
            }

            if (lastRow == null) {
                // Fallback: use the last row number if no non-empty row found
                lastRow = sheet.getRow(lastRowNum);
                logger.info("Using last row index: " + lastRowNum + " (no non-empty Tranche ID found in previous rows)");
            }

            // Read values from last row using DataFormatter for proper cell value reading
            org.apache.poi.ss.usermodel.DataFormatter formatter = new org.apache.poi.ss.usermodel.DataFormatter();

            if (trancheIdCol >= 0 && lastRow.getCell(trancheIdCol) != null) {
                storedTrancheId = formatter.formatCellValue(lastRow.getCell(trancheIdCol)).trim();
            }
            if (windowStartCol >= 0 && lastRow.getCell(windowStartCol) != null) {
                storedWindowStart = formatter.formatCellValue(lastRow.getCell(windowStartCol)).trim();
            }
            if (windowEndCol >= 0 && lastRow.getCell(windowEndCol) != null) {
                this.storedWindowEnd = formatter.formatCellValue(lastRow.getCell(windowEndCol)).trim();
            }

            logger.info("Read from last row - Tranche ID: '" + storedTrancheId +
                    "', Window Start: '" + storedWindowStart + "', Window End: '" + storedWindowEnd + "'");

        } catch (Exception e) {
            throw new RuntimeException("Failed to read Tranche ID from Uploaded_Tranche.xlsx: " + e.getMessage(), e);
        }

        if (storedTrancheId.isEmpty()) {
            throw new RuntimeException("No Tranche ID found in Uploaded_Tranche.xlsx");
        }

        logger.info("Using Tranche ID: " + storedTrancheId + " start:" + storedWindowStart + " end:" + storedWindowEnd);

        By searchBoxLocator = service.getLookupBy("SDP Existing Tranche Search Box");
        WebElement input = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> driver.findElement(searchBoxLocator));
        input.clear();
        input.sendKeys(storedTrancheId);
    }

    @When("^set Window Period Start and EndDate from stored Tranche file$")
    public void setWindowPeriodFromStored() {
        assertService();


        By startDateBoxLocator = service.getLookupBy("SDP Window Period Start Date Box");
        WebElement startDateBox = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> driver.findElement(startDateBoxLocator));
        startDateBox.click();

        By startDayLocator = service.getLookupBy("SDP Window Period Start Date SELECTION");
        WebElement startDay = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> driver.findElement(startDayLocator));
        startDay.click();

        By endDateBoxLocator = service.getLookupBy("SDP Window Period End Date");
        WebElement endDateBox = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> driver.findElement(endDateBoxLocator));
        endDateBox.click();

        By endDayLocator = service.getLookupBy("SDP Window Period End Date SELECTION");
        WebElement endDay = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> driver.findElement(endDayLocator));
        endDay.click();


        logger.info("Selected window period start and end dates in UI.");
    }

    // ---------------------------------------------------------------------
    // Step: Upload a termsheet file by using a UI element key for the file input
    // Called by snippet: upload file 'English Termsheet PDF.pdf' using 'SDP English Termsheet Input'
    // Note: Using different pattern to avoid conflict with SDPortal_FXSDTrancheUploadGlue
    // ---------------------------------------------------------------------
    @And("^upload termsheet file '(.+)' using '(.+)'$")
    public void uploadTermsheetFile(String requestedFileName, String inputElementKey) {
        assertService();

        // Locate the PDF file from SDTermsheets folder
        String filePath = locateTermsheetFile(requestedFileName);
        logger.info("Uploading termsheet file: " + requestedFileName + " from path: " + filePath);

        // Resolve the file input element on the UI using the element repository key
        By fileInputBy = service.getLookupBy(inputElementKey);
        WebElement fileInput = null;
        try {
            fileInput = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                    .until(driver -> {
                        WebElement el = driver.findElement(fileInputBy);
                        // Ensure element is present and can be interacted with
                        if (el != null && el.isEnabled()) {
                            return el;
                        }
                        return null;
                    });
        } catch (Exception e) {
            throw new RuntimeException("File input element not found or not enabled: " + inputElementKey + " - " + e.getMessage(), e);
        }

        // Upload logic (primary strategy: sendKeys on <input type="file">)
        try {
            // Always use JavaScript to ensure file input is accessible
            ((JavascriptExecutor) service.getWebDriver())
                    .executeScript("arguments[0].style.display='block'; arguments[0].style.visibility='visible'; arguments[0].style.opacity='1'; arguments[0].style.position='relative'; arguments[0].style.zIndex='9999';", fileInput);

            // Small wait to ensure element is ready
            Thread.sleep(500);

            // Clear any existing value first
            fileInput.clear();

            // Send the file path
            fileInput.sendKeys(filePath);
            logger.info("File path sent to input element: " + inputElementKey);

            // Wait a bit to ensure file is selected
            Thread.sleep(500);

            // Hide the input again to restore original UI
            ((JavascriptExecutor) service.getWebDriver())
                    .executeScript("arguments[0].style.display='none'; arguments[0].style.visibility='hidden';", fileInput);

        } catch (Exception ex) {
            throw new RuntimeException("Failed to upload file: " + requestedFileName + " using element: " + inputElementKey + " - " + ex.getMessage(), ex);
        }
    }

    // ---------------------------------------------------------------------
    // Step: Assert that uploaded termsheet file name matches expected
    // Called by snippet: assert that uploaded termsheet file name is '$1' in 'SDP English Termsheet File Name'
    // Note: Using different pattern to avoid conflict with SDPortal_FXSDTrancheUploadGlue
    // ---------------------------------------------------------------------
    @Then("^assert that uploaded termsheet file name is '(.+)' in '(.+)'$")
    public void assertUploadedTermsheetFileName(String expectedFileName, String elementKey) {
        assertService();

        By elementBy = service.getLookupBy(elementKey);

        // Wait for file name to update (not "Not available" anymore)
        WebElement element = service.getWebDriverWait(30L, java.util.concurrent.TimeUnit.SECONDS)
                .until(driver -> {
                    WebElement el = driver.findElement(elementBy);
                    String text = el.getText().trim();
                    // Wait until the text is not "Not available" and contains the expected file name
                    return !text.equalsIgnoreCase("Not available") && text.contains(expectedFileName) ? el : null;
                });

        String displayed = element.getText().trim();

        // Assert the UI displays expected file name (contains check is safer if UI adds extra text)
        if (!displayed.contains(expectedFileName)) {
            throw new AssertionError("Uploaded filename mismatch. Expected to contain: " + expectedFileName + " but was: " + displayed);
        }
    }

    /**
     * Locate termsheet PDF file from SDTermsheets folder
     */
    private String locateTermsheetFile(String fileName) {
        // Try multiple locations
        String[] possiblePaths = {
                "src/test/resources/data/SDPortal/SDTermsheets/" + fileName,
                "data/SDPortal/SDTermsheets/" + fileName,
                fileName
        };

        for (String path : possiblePaths) {
            java.io.File file = new java.io.File(path);
            if (file.exists() && file.isFile()) {
                return file.getAbsolutePath();
            }
        }

        // Try classpath
        try {
            java.io.InputStream is = getClass().getClassLoader().getResourceAsStream("data/SDPortal/SDTermsheets/" + fileName);
            if (is != null) {
                // Copy to temp file
                java.io.File tempFile = java.io.File.createTempFile("termsheet_", ".pdf");
                java.nio.file.Files.copy(is, tempFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                is.close();
                return tempFile.getAbsolutePath();
            }
        } catch (Exception e) {
            // Continue to throw error
        }

        throw new RuntimeException("Termsheet file not found: " + fileName + ". Tried paths: " + String.join(", ", possiblePaths));
    }

    /* -------------------------
     * helper and assertions
     * -------------------------
     */

    private void assertService() {
        if (this.service == null) {
            throw new IllegalStateException("SeleniumService is null. Ensure Genie initialized the seleniumService attribute.");
        }
    }

}


/*
 * NOTES on some utility references used above:
 * - TrancheUploadHelper.uploadFile(service, inputElement, filePath) : This is the helper you told me exists. It should:
 *      1) take the File input WebElement and set the file path via sendKeys(filePath) or use OS upload (depending on implementation),
 *      2) wait for the file to be attached and return control to test code.
 *
 * - ExcelHelper.getLatestTrancheId() : small wrapper to your ExcelDriver/Workbook utility to read the latest Tranche ID and window dates
 *   from the Tranche upload workbook you maintain. Replace with exact class/method names from your project.
 *
 * - service.waitForElement(By) and service.getLookupBy("name") : these methods reflect the patterns in the working glue files you already have
 *   (service.getLookupBy returns By constructed from the JSON locator). If your SeleniumService API uses other method names, adapt accordingly,
 *   but keep method responsibilities identical.
 */
