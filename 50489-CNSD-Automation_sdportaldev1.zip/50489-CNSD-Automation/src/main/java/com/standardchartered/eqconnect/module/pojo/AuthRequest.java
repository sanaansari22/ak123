package com.standardchartered.eqconnect.module.pojo;

/**
 * AuthRequest
 *
 * Purpose:
 * --------
 * POJO representing the request body for:
 *    POST /eqd/auth/logon
 *
 * Why POJO:
 * ---------
 * - Genie REST (Jackson) automatically serializes this object to JSON
 * - Keeps API contract strongly typed
 * - Avoids manual JSON string creation
 *
 * JSON produced:
 * --------------
 * {
 *   "bank_id": "xxxx",
 *   "password": "yyyy"
 * }
 */
public class AuthRequest {

    private String bank_id;
    private String password;

    public AuthRequest(String bankId, String password) {
        this.bank_id = bankId;
        this.password = password;
    }

    public String getBank_id() {
        return bank_id;
    }

    public String getPassword() {
        return password;
    }
}