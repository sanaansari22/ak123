package com.standardchartered.eqconnect.module.support;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class excelDriver {

    File f ;//= new File(fileLocation);
    FileInputStream inputStream;
    FileOutputStream outputStream;
    XSSFWorkbook wb;
    XSSFSheet sheet;
    Workbook workbook;// = WorkbookFactory.create(inputStream);
//    Sheet sheet;// = workbook.getSheet(operationName);

        public void setCellValue(String excelName,String TestcaseName, String paramName, String paramVal){
//        Iterator<Row> rowIterator = sheet.rowIterator();
        sheet = getExcel(excelName);
        int celNum = 0;
        for(int x =0; x < sheet.getRow(0).getPhysicalNumberOfCells();x++){
            if(sheet.getRow(0).getCell(x).toString().equalsIgnoreCase(paramName)){
                celNum = x;
                break;
            }
        }
        if(celNum == 0) {
            celNum = sheet.getRow(0).getPhysicalNumberOfCells();
           // System.out.println(celNum);
            sheet.getRow(0).createCell(celNum).setCellValue(paramName);
           // System.out.println(sheet.getRow(0).getCell(celNum));
           // System.out.println(sheet.getRow(0).getCell(celNum-1));
//            sheet.getRow(0).getCell(celNum).setCellValue(paramName);
          /*  int newCellNum = sheet.getRow(0).getPhysicalNumberOfCells()+1;
            int newRowNum = sheet.getPhysicalNumberOfRows()+1;
            Cell cell = sheet.getRow(0).createCell(newCellNum);
            cell.setCellValue(paramName);
            sheet.createRow(newRowNum).createCell(0).setCellValue(TestcaseName);
            sheet.createRow(newRowNum).createCell(newCellNum).setCellValue(TestcaseName);*/
        }

        int rowNum = 0;
       // System.out.println(sheet.getPhysicalNumberOfRows());
        for(int y = 1; y < sheet.getPhysicalNumberOfRows();y++){
           // System.out.println(sheet.getRow(y).getCell(0).toString());
            if(sheet.getRow(y).getCell(0).toString().toLowerCase().equals(TestcaseName.toLowerCase())){
                rowNum = y;
                break;
            }
        }
       // System.out.println("rowNum - "+rowNum);
       // System.out.println("celNum - "+celNum);
        if(rowNum == 0) {
            int newRowNum = sheet.getPhysicalNumberOfRows();
            sheet.createRow(newRowNum);
            sheet.getRow(newRowNum).createCell(0).setCellValue(TestcaseName);
            sheet.getRow(newRowNum).createCell(celNum).setCellValue(paramVal);
        }
        else {
            sheet.getRow(rowNum).createCell(celNum).setCellValue(paramVal);
        }

        try {
            outputStream = new FileOutputStream(f);
            wb.write(outputStream);
        }
        catch (Exception e) {
           // System.out.println("Error writing to file - "+e.toString());
        }
        closeConnections();

    }

    public String getCellValue(String excelName,String TestcaseName, String paramName){
        sheet = getExcel(excelName);
        int celNum = 0;
        String paramVal = "";
       // System.out.println(sheet.getRow(0).getCell(0).toString());
        for(int x =0; x < sheet.getRow(0).getPhysicalNumberOfCells();x++){
            if(sheet.getRow(0).getCell(x).toString().toLowerCase().equals(paramName.toLowerCase())){
                celNum = x;
                break;
            }
        }
       // System.out.println("CellNum "+celNum);
        if(celNum != 0){
            for(int y = 1; y < sheet.getPhysicalNumberOfRows();y++){
               // System.out.println(sheet.getRow(y).getCell(0).toString().toLowerCase());
                if(sheet.getRow(y).getCell(0).toString().toLowerCase().equals(TestcaseName.toLowerCase())){
                    paramVal = sheet.getRow(y).getCell(celNum).toString();
                    break;
                }
            }
        }
        else{
            System.out.println("Parameter doesnt exists");
        }
        closeConnections();
        System.out.println(paramVal);
        return paramVal;
    }

    public void closeConnections(){
        try {
//            outputStream.close();
            inputStream.close();
        }catch(Exception e){
           // System.out.println("issue in closing excel drivers");
        }
    }

    public XSSFSheet getExcel(String fileName) {
        f = new File("src/test/resources/data/"+fileName+".xlsx");
        if(!f.exists())
            System.out.println("Please create a file under data folder with following name : "+fileName);
        try {
            inputStream = new FileInputStream(f);
//            outputStream = new FileOutputStream(f);
//            workbook = WorkbookFactory.create(inputStream);
            wb = new XSSFWorkbook(inputStream);
            sheet = wb.getSheetAt(0);
        }catch (Exception e){
           // System.out.println(e.toString());
        }
        return sheet;
    }

    public String getPath() {
        return f.getPath();
    }
}
