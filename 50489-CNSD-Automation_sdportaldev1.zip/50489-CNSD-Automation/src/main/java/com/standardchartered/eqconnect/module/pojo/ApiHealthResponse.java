package com.standardchartered.eqconnect.module.pojo;

import java.util.List;

/**
 * ApiHealthResponse
 *
 * Purpose:
 * --------
 * POJO for response returned by:
 *    GET /eqd/accounts/health/ebbs
 *
 * Expected JSON:
 * --------------
 * {
 *   "data": [
 *     {
 *       "apiName": "CustomerService",
 *       "status": "UP"
 *     }
 *   ]
 * }
 *
 * Why this structure:
 * -------------------
 * - Matches backend response exactly
 * - Allows clean iteration and comparison with UI
 */
public class ApiHealthResponse {

    private List<ApiStatus> data;

    public List<ApiStatus> getData() {
        return data;
    }

    /**
     * Inner POJO representing each API status block
     */
    public static class ApiStatus {

        private String apiName;
        private String status;

        public String getApiName() {
            return apiName;
        }

        public String getStatus() {
            return status;
        }
    }
}
