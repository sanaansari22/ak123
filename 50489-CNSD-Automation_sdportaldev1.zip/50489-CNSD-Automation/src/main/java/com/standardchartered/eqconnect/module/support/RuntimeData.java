package com.standardchartered.eqconnect.module.support;

public class RuntimeData {

    private String trancheID;
    private String RFQID;
    private String dealNo_1;
    private String dealNo_2;

    public RuntimeData() {
        super();
    }

    public String getRFQID(){
        return RFQID;
    }

    public void setRFQID(String RFQID){
        this.RFQID = RFQID;
    }


}
