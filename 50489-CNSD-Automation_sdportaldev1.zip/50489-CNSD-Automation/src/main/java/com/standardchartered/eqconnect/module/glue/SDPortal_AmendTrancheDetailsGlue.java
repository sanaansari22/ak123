package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.core.util.SeleniumAssertionUtil;
import com.standardchartered.genie.module.selenium.glue.transformer.LookupByTransformer;
import com.standardchartered.eqconnect.module.support.excelDriver;
import cucumber.api.Scenario;
import cucumber.api.Transform;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import static com.standardchartered.eqconnect.module.glue.genericGlue.waitfor;

/**
 * SDPortal_AmendTrancheDetailsGlue
 *
 * Glue for TC 6610802 (Maker Amend FXSD Tranche).
 *
 */
public class SDPortal_AmendTrancheDetailsGlue {

    private static final Logger logger = Logger.getLogger(SDPortal_AmendTrancheDetailsGlue.class.getName());
    private SeleniumService service;
    private GenieScenario scenario;
    private excelDriver excel;


    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        // Initialize the scenario object
        this.scenario = (GenieScenario) cucumberScenario;
        if (this.scenario != null) {
            this.service = scenario.getRuntime().getAttribute("seleniumService");
            if (this.service == null) {
                logger.severe("seleniumService is not initialized");
            } else {
                logger.info("seleniumService is initialized successfully");
            }
        } else {
            logger.severe("GenieScenario is not initialized");
        }

        // Initialize the excelDriver
        this.excel = new excelDriver();
    }


    @And("^update amend priority from tranche flow excel '(.+)'$")
    public void updateAmendPriorityFromTrancheFlow(String priorityKey) {
        try {
            // Read the priority value from the Excel file
            String excelFileName = "TrancheFlow"; // Update with your Excel file name without extension
            String testCaseName = "TC6610802"; // Update with your test case name
            String priorityValue = excel.getCellValue(excelFileName, testCaseName, priorityKey);

            // Locate Priority input using Genie lookup
            WebElement priorityField = service.getWebDriver()
                    .findElement(service.getLookupBy("SDP Maker Amend Priority Field"));
            waitfor(3);

            // Clear existing value (e.g. 2)
            priorityField.clear();
            waitfor(3);

            // Enter new value (e.g. 4)
            priorityField.sendKeys(priorityValue);
        } catch (Exception e) {
            logger.severe("Failed to update amend priority: " + e.getMessage());
        }
    }

    @And("^enter the amendment reason from tranche flow excel '(.+)'$")
    public void updateAmendReasonFromTrancheFlow(String reasonKey) {
        try {
            // Read the amendment reason from the Excel file
            String excelFileName = "TrancheFlow"; // Update with your Excel file name without extension
            String testCaseName = "TC6610802"; // Update with your test case name
            String amendReason = excel.getCellValue(excelFileName, testCaseName, reasonKey);

            // Locate Amendment Reason input
            WebElement reasonField = service.getWebDriver()
                    .findElement(service.getLookupBy("SDP Maker Amendment Reason Field"));
            waitfor(3);
            // Clear if any value exists
            reasonField.clear();
            waitfor(3);

            // Enter amendment reason
            reasonField.sendKeys(amendReason);
        } catch (Exception e) {
            logger.severe("Failed to update amend reason: " + e.getMessage());
        }
    }

    @Then("^verify amend success message contains '(.*)'$")
    public void verifyAmendSuccessMessage(String elementKey) {
        try {
            // Wait for success message container to be visible first
            By successContainerBy = By.cssSelector(".components-alert-modal__container");
            WebElement successContainer = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                    .until(ExpectedConditions.presenceOfElementLocated(successContainerBy));

            // Wait for the span element inside container to have text
            By successMsgBy = service.getLookupBy(elementKey);
            WebElement msg = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                    .until(driver -> {
                        try {
                            WebElement span = driver.findElement(successMsgBy);
                            String text = span.getText().trim();
                            // Wait until text appears and contains "Successfully"
                            if (text != null && !text.isEmpty() && text.contains("Successfully")) {
                                return span;
                            }
                            return null;
                        } catch (Exception e) {
                            return null;
                        }
                    });
        } catch (Exception e) {
            logger.severe("Failed to verify amend success message: " + e.getMessage());
        }
    }
    @Then("^verify that '(.+)' contains value of '(.+)'$")
    public void assertTextIsPresentOnElement(@Transform(LookupByTransformer.class) By elementLookup, String expectedText) {
        try {
            // Read the expected text value from the Excel file
            String excelFileName = "TrancheFlow"; // Update with your Excel file name without extension
            String testCaseName = "TC6610802"; // Update with your test case name
            String expectedValue = excel.getCellValue(excelFileName, testCaseName, expectedText);

            // Assert that the element contains the expected text
            SeleniumAssertionUtil.assertTextIsPresentOnElement(service.getWebDriverWait(30L, TimeUnit.SECONDS), elementLookup, expectedValue);
        } catch (Exception e) {
            logger.severe("Failed to assert that element contains the expected value: " + e.getMessage());
        }
    }
}