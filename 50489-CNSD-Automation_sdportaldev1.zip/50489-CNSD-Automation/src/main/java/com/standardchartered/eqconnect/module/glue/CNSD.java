package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.GenieGenericsService;
import com.standardchartered.genie.downloader.replicator.listener.SystemOutLoggerReplicatorListener;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static com.standardchartered.eqconnect.module.glue.genericGlue.waitfor;
import static com.standardchartered.genie.module.selenium.core.util.SeleniumAssertionUtil.assertTextIsPresentOnElement;

public class CNSD {

    private GenieScenario scenario;
    private SeleniumService service;
    private GenieGenericsService GenieService;


    @Before("@selenium")
    public void beforeScenario(Scenario scenario) {
        this.scenario = (GenieScenario) scenario;
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");
    }

    @And("^scroll to the bottom$")
    public void scrolltothebottom() {
//        service.getWebDriver().findElement(service.getLookupBy("ExpandButton")).click();
        waitfor(3);
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("window.scrollTo(0,document.body.scrollHeight");
        waitfor(3);
    }

    @And("^scroll to the bottom of '(.+)'$")
    public void scrolltothebottomof(String ele) {
        waitfor(3);
        WebElement container =  service.getWebDriver().findElement(service.getLookupBy(ele));
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;",container);
        waitfor(3);
    }
    @And("^Subtract '([0-9]+)' from '(.+)'$")
    public void Arthimeticsubtract(int y,String x){
       /* System.out.println((String) scenario.getAttribute(x));
        System.out.println(Integer.parseInt((String) scenario.getAttribute(x)));
        System.out.println(Integer.parseInt(scenario.getAttribute(x)) - y);
        System.out.println(y);*/
        scenario.setAttribute(x, Integer.parseInt((String) scenario.getAttribute(x)) - y);
    }

    @And("^Add '([0-9]+)' to '(.+)'$")
    public void ArthimeticAddition(int y,String x){
       /* System.out.println((String) scenario.getAttribute(x));
        System.out.println(Integer.parseInt((String) scenario.getAttribute(x)));
        System.out.println(Integer.parseInt(scenario.getAttribute(x)) - y);
        System.out.println(y);*/
        scenario.setAttribute(x, Integer.parseInt((String) scenario.getAttribute(x)) + y);
    }

    @And("^special type text '(.+)' into '(.+)'$")
    public void specialEnterText(String val, String ele) {
        WebElement container =  service.getWebDriver().findElement(service.getLookupBy(ele));
        waitfor(3);
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("arguments[0].value = arguments[1]",container,val);
        waitfor(3);
    }

    @And("^special type value of '(.+)' into '(.+)'$")
    public void specialEnterValueOfText(String val, String ele) {
        WebElement container =  service.getWebDriver().findElement(service.getLookupBy(ele));
        waitfor(3);
        JavascriptExecutor js = (JavascriptExecutor) service.getWebDriver();
        js.executeScript("arguments[0].value = arguments[1]",container,scenario.getAttribute(val));
        waitfor(3);
    }

}
