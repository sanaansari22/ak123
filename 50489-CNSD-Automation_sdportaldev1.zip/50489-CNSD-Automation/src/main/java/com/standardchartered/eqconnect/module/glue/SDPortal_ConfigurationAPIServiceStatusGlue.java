package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.eqconnect.module.support.NetworkCsvCaptureUtils;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class SDPortal_ConfigurationAPIServiceStatusGlue {
    private static final Logger logger = Logger.getLogger(SDPortal_ReportsGlue.class.getName());
    private static final Path DEST_FOLDER = Paths.get("./data/SDPortal/SDPortalReports");
    private static String customerDetail = "";
    private GenieScenario scenario;
    private SeleniumService service;
    HashMap<String, String> apiStatus;

    // ---------------------------------------------------------
    // Before Hook
    // ---------------------------------------------------------
    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        logger.info("Initializing scenario...");
        try {
            this.scenario = (GenieScenario) cucumberScenario;
            this.service = this.scenario.getRuntime().getAttribute("seleniumService");
            this.service = this.scenario.getRuntime().getAttribute("seleniumService");

            logger.info("SeleniumService initialized successfully.");
        } catch (Exception e) {
            logger.severe("Error initializing Selenium service: " + e.getMessage());
            throw e;
        }
    }

    @And("^Get the status of customer with customer id '(.+)'$")
    public void getCustomerDetails(String customerId) {
        RestAssured.baseURI = "https://cnlvadeqc001.cn.standardchartered.com:8463";
        String authToken = RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Content-Type", "application/json")
                .header("Origin", "https://cnlvadeqc001.cn.standardchartered.com:8463")
                .cookie("JSESSIONID", "FCB1C623679173DB938B5ADFB3C683ED")
                .header("Sec-Fetch-Mode", "cors")
                .header("channelCode", "02")
                .header("Referer", "https://cnlvadeqc001.cn.standardchartered.com:8463/wm/full/cnsd/index2.html")
                .body("{\"bank_id\":\"1568256\",\"password\":\"czq3Mi3opTH6IA7rNsvE6g==\"}")
                .when().post("/eqd/auth/logon")
                .getHeader("Auth-Token");

        customerDetail = RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Content-Type", "application/json")
                .header("Origin", "https://cnlvadeqc001.cn.standardchartered.com:8463")
                .header("Sec-Fetch-Mode", "cors")
                .header("auth-token", authToken)
                .header("correlationId", "1765642769433")
                .header("Referer", "https://cnlvadeqc001.cn.standardchartered.com:8463/wm/full/cnsd/index2.html")
                .when().get("/eqd/accounts/health/ebbs?customerId=" + customerId)
                .asString();
    }

    @Then("^fetch the api status on UI$")
    public void fetchTheStatusOnUI() {
        List<WebElement> allElems = this.service.getWebDriver().findElements(By.xpath("//div[@class='config__status-name']"));
        apiStatus = new HashMap<>();
        for (WebElement elem : allElems) {
            apiStatus.put(elem.getText(), this.service.getWebDriver().findElement(By.xpath("//div[text()='" + elem.getText() + "']/following-sibling::div[1][@class='config__status-status']/span")).getText());
        }
    }

    @Then("^validate the api status on UI$")
    public void validateTheStatusOnUI() {
        JsonPath json = new JsonPath(customerDetail);
        List<Map<String, String>> data = json.getList("data");
        for(Map<String, String> temp: data){
            System.out.println("=============="+temp.get("apiName"));
            System.out.println("=============="+temp.get("status"));
            System.out.println("=============="+apiStatus.get(temp.get("apiName")));
//            Assert.assertEquals(temp.get("status"), apiStatus.get(temp.get("apiName")));
        }
    }}

