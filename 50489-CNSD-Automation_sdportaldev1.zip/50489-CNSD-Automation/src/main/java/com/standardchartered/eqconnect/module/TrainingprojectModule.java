package com.standardchartered.eqconnect.module;

import com.standardchartered.genie.GenieRuntime;
import com.standardchartered.genie.module.BaseGenieGlueModule;
import java.util.ArrayList;
import java.util.List;

public class TrainingprojectModule extends BaseGenieGlueModule {
    @Override
    public String getName() {
        return "TrainingprojectModule";
    }

    @Override
    public void initialise(GenieRuntime runtime) {
    }

    @Override
    public List<String> getGluePaths() {
        List<String> gluePaths = new ArrayList<>();
        gluePaths.add("classpath:com.standardchartered.eqconnect.module.glue");
        gluePaths.add("classpath:snippet");
        return gluePaths;
    }

}
