package com.standardchartered.eqconnect.module.glue;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import static com.standardchartered.eqconnect.module.glue.genericGlue.waitfor;

/**
 * SDPortal_TrancheApprovalGlue
 *
 * Glue for TC 5578611 (Checker approves FXSD Tranche).
 * Reuses step definitions from SDPortal_TermsheetUploadGlue for search functionality.
 */
public class SDPortal_TrancheRejectGlue {

    private static final Logger logger = Logger.getLogger(SDPortal_ViewTrancheDetailsGlue.class.getName());
    private SeleniumService service;

    @Before("@selenium")
    public void beforeScenario(Scenario cucumberScenario) {
        GenieScenario scenario = (GenieScenario) cucumberScenario;
        this.service = scenario.getRuntime().getAttribute("seleniumService");
        if (this.service == null) {
            logger.severe("seleniumService is not initialized");
        } else {
            logger.info("seleniumService is initialized successfully");
        }
    }
    /**
     * Enter reject reason with Checker login
     */

    @And("^enter reject reason in '(.*)'$")
    public void enterRejectReasonValue(String rejectInputBox) {
        try {
            // Locate the reject reason field
            WebElement rejectReasonField = service.getWebDriver().findElement(service.getLookupBy(rejectInputBox));

            // Enter the value 'reject' into the field
            rejectReasonField.sendKeys("reject");

            // Wait for 2 seconds to ensure the value is entered
            waitfor(2);
        } catch (Exception e) {
            // Print an error message if the field is not displayed or any other exception occurs
            System.out.print("Text field is not displayed on the page --- Exception message : " + e.getMessage());
        }
    }
    /**
     * Verify reject success message (checks element text contains expected message)
     */
    @Then("^verify reject success message '(.+)'$")
    public void verifyRejectSuccessMessage(String expectedMessage) {
        WebElement messageElement = service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(ExpectedConditions.presenceOfElementLocated(service.getLookupBy("SDP Checker Reject Success Message")));
        String actualMessage = messageElement.getText();
        Assert.assertTrue("Reject success message not found. Expected: " + expectedMessage + ", Actual: " + actualMessage,
                actualMessage.contains(expectedMessage));
        logger.info("Verified reject success message: " + expectedMessage);
    }
}