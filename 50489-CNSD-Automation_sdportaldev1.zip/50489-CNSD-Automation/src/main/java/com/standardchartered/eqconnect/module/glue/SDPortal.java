package com.standardchartered.eqconnect.module.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;
import com.standardchartered.genie.module.selenium.core.util.SeleniumWindowUtil;
import com.standardchartered.genie.module.selenium.driver.service.WebDriverSession;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import org.openqa.selenium.JavascriptExecutor;

import static com.standardchartered.genie.module.selenium.core.util.SeleniumWindowUtil.switchToWindowName;
import static org.junit.Assert.assertTrue;
public class SDPortal {

    private GenieScenario scenario;
    private SeleniumService service;
    static final Logger logger = Logger.getLogger(SDPortal.class.getName());


    @Before("@selenium")
    public void beforeScenario(Scenario scenario) {
        this.scenario = (GenieScenario) scenario;
        this.service = this.scenario.getRuntime().getAttribute("seleniumService");
        if (this.service == null) {
            logger.severe("seleniumService is not initiallized");
        } else {
            logger.info("seleniumService is initiallized successfully");
        }
    }

    @Then("^User should see SDPortal dashboard for role '(.+)'$")
    public void verifyDashBoardForRole(String role) {
        try {
            // The element name in the elements JSON: SSDP PostLogin Unique HomeCard
            WebElement element = service.getWebDriver().findElement(service.getLookupBy(role));
            assertTrue("SSDP PostLogin Unique HomeCard", element.isDisplayed());
        } catch (Exception e) {
            logger.severe("Element not found or not displayed:" + e.getMessage());
            // Fall back to title
            String title = service.getWebDriver().getTitle();
            assertTrue("Title contain MALI-E or Dashboard", title.contains("MALI-E") || title.contains("Dashboard"));
        }
    }

    // Wait for element to be visible - common utility for all SDPortal scenarios
    // 30L = 30 seconds timeout (L means Long type)
    @And("^wait for element '(.+)' to be visible$")
    public void waitForVisible(String elementKey) {
        // Use explicit wait provided by SeleniumService; avoid Thread.sleep
        service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(driver -> driver.findElement(service.getLookupBy(elementKey)).isDisplayed());
    }

    // Wait for element to be enabled - common utility for all SDPortal scenarios
    @And("^wait for element '(.+)' to be enabled$")
    public void waitForEnabled(String elementKey) {
        // Wait until element is both visible and enabled, and doesn't have disabled class
        service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(driver -> {
                    try {
                        WebElement el = driver.findElement(service.getLookupBy(elementKey));
                        String classAttr = el.getAttribute("class");
                        // Check if element is displayed, enabled, and doesn't have --disabled in class
                        return el.isDisplayed() && el.isEnabled() && (classAttr == null || !classAttr.contains("--disabled"));
                    } catch (Exception e) {
                        return false;
                    }
                });
    }

    // Wait for element to be present in DOM (for hidden elements like file inputs)
    @And("^wait for element '(.+)' to be present$")
    public void waitForPresent(String elementKey) {
        // Wait until element is present in DOM (doesn't check visibility)
        service.getWebDriverWait(30L, TimeUnit.SECONDS)
                .until(driver -> {
                    try {
                        WebElement el = driver.findElement(service.getLookupBy(elementKey));
                        return el != null;
                    } catch (Exception e) {
                        return false;
                    }
                });
    }

}