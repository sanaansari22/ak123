//(Page Helper — all file / Excel / ID-generation logic lives here; no WebDriver calls)
package helpers;

/*
 * SDTranchUploadHelper.java
 *
 * Author: Sana Ansari
 * Source reference: /mnt/data/FXSD Tranche Upload Test Automation code.docx
 *
 * Purpose:
 *  - This helper contains all file and Excel manipulation required to prepare the tranche upload file.
 *  - Responsibilities include locating the sample template, copying to a dated file, updating Tranche_ID
 *    values inside the Excel rows to include today's date, ensuring uniqueness, and persisting uploaded IDs.
 *
 * Design note:
 *  - This helper does NOT perform any browser interactions (clicks/findElement/sendKeys).
 *    Browser interactions belong to the glue (SDPortal_FXSDTrancheUploadGlue).
 *
 * Usage:
 *  - Glue calls prepareTrancheFile(requestedFileName) which returns absolute path to the prepared file.
 *  - Glue then uses that path to perform a WebDriver sendKeys on the file input element.
 */

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SDTranchUploadHelper {

    // Root relative path used to search for sample templates in repo
    private static final String DEFAULT_SAMPLE_DIR = "src/test/resources/data/SDPortal/TrancheFiles/";

    // Regex to detect an 8-digit date in filename (yyyyMMdd)
    private static final Pattern EIGHT_DIGIT_DATE_PATTERN = Pattern.compile("\\d{8}");

    // Pattern for Tranche ID inside Excel rows - supports multiple formats
    // Format 1: PREFIX + 6digitDate(yyMMdd) + MID + number + SUFFIX -> "MALI251130BUC10CY"
    // Format 2: PREFIX + 4digitDate(yyMM) + MID + number + SUFFIX -> "MALI2511BLNPPR03BD"
    // The MID part can contain letters and numbers (e.g., "BL90PR", "ELINPPR")
    // IMPORTANT: If original has 6 digits, replace with yyMMdd (6 digits). If 4 digits, replace with yyMM (4 digits).
    // This ensures the total Tranche ID length remains max 18 characters.
    // NOTE: Check for 6 digits FIRST, then 4 digits (order matters in regex alternation)
    private static final Pattern TRANCHE_ID_PATTERN = Pattern.compile("([A-Z]+)(\\d{6}|\\d{4})([A-Z0-9]+)(\\d+)([A-Z]+)");
    private static final String UPLOADED_TRANCHE_PATH = "src/test/resources/data/SDPortal/Uploaded_Tranche.xlsx";

    /**
     * Prepare the tranche Excel file for upload.
     *
     * Steps performed:
     *  - Normalize sample name (replace actual date with placeholder YYYYMMDD)
     *  - Build target filename by replacing YYYYMMDD with today's yyyyMMdd
     *  - Locate the sample file (multiple strategies)
     *  - Copy sample → target
     *  - Update Tranche_ID values inside the target workbook to today's date (yyMMdd)
     *
     * @param requestedFileName the name used in feature/snippet (may contain YYYYMMDD or a date)
     * @return absolute path to the prepared target file ready for upload
     */
    public String prepareTrancheFile(String requestedFileName) {

        // 1) Normalize sample file name to include placeholder
        String sampleFileName = normalizeSampleFileName(requestedFileName);

        // 2) Compute target filename with today's date in yyyyMMdd format (always ensure physical copy has dated name)
        String todayYYYYMMDD = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String targetFileName = resolveTargetFileName(sampleFileName, requestedFileName, todayYYYYMMDD);

        // 3) Locate sample file on disk or classpath
        File sampleFile = locateSampleExcel(sampleFileName);

        // 4) Ensure the target file path is built in sample file's directory
        String targetPath = buildTargetFilePath(sampleFile, targetFileName);

        // 5) Copy sample -> target (overwrite if already present)
        copySampleToTarget(sampleFile, targetPath);

        // 6) Update tranche IDs + all dependent dates inside the target workbook
        //    (this guarantees unique IDs per day and synthesises all date milestones)
        updateTrancheIdsInExcel(targetPath);

        // 7) Return absolute path to the prepared file
        return new File(targetPath).getAbsolutePath();
    }

    // -----------------------------
    // Helpers: normalization & locating
    // -----------------------------
    private String normalizeSampleFileName(String original) {
        // If original contains an 8-digit date, replace it with YYYYMMDD placeholder
        Matcher m = EIGHT_DIGIT_DATE_PATTERN.matcher(original);
        if (m.find()) {
            return m.replaceAll("YYYYMMDD");
        }
        // If already contains YYYYMMDD, use as-is
        if (original.contains("YYYYMMDD")) {
            return original;
        }
        // Otherwise treat given name as sample name; prefer adding placeholder not needed
        return original;
    }

    private File locateSampleExcel(String sampleFileName) {
        List<String> tried = new ArrayList<>();

        // Try the single configured sample directory
        String path = DEFAULT_SAMPLE_DIR + sampleFileName;
        tried.add(path);
        File f = new File(path);
        if (f.exists() && f.isFile()) {
            return f;
        }

        // Next, try to load from classpath resources
        try (InputStream is = getClass().getClassLoader()
                .getResourceAsStream("data/SDPortal/TrancheFiles/" + sampleFileName)) {
            if (is != null) {
                // Copy classpath resource to a temp file and return it
                File temp = File.createTempFile("sampleTranche", ".xlsx");
                Files.copy(is, temp.toPath(), StandardCopyOption.REPLACE_EXISTING);
                return temp;
            } else {
                tried.add("classpath:data/SDPortal/TrancheFiles/" + sampleFileName + " (not found)");
            }
        } catch (IOException e) {
            // Swallow and rethrow after collecting tried paths
        }

        // If none found → throw informative exception with paths tried
        throw new RuntimeException("Sample Excel file not found. Paths tried: " + String.join(", ", tried));
    }

    private String buildTargetFilePath(File sampleFile, String targetFileName) {
        File parent = sampleFile.getParentFile();
        if (parent == null) {
            // Fallback to current working directory
            parent = new File(System.getProperty("user.dir"));
        }
        return new File(parent, targetFileName).getAbsolutePath();
    }

    private void copySampleToTarget(File source, String targetPath) {
        try {
            // Ensure parent dir exists
            File target = new File(targetPath);
            File parent = target.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }

            // Copy the file; replace existing if present
            Files.copy(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("Failed to copy sample to target: " + e.getMessage(), e);
        }
    }

    /**
     * Resolve the final filename that should be generated on disk.
     * Priority order:
     *   1. If the sample already contains the placeholder, replace it with today's date.
     *   2. Otherwise, if the requested filename contains the placeholder, replace there.
     *   3. Otherwise, if requester already passed an explicit date, honour it.
     *   4. Fallback: append _yyyyMMdd before the extension to guarantee a dated filename.
     */
    private String resolveTargetFileName(String sampleFileName, String requestedFileName, String today) {

        if (sampleFileName != null && sampleFileName.contains("YYYYMMDD")) {
            return sampleFileName.replace("YYYYMMDD", today);
        }

        if (requestedFileName != null) {
            if (requestedFileName.contains("YYYYMMDD")) {
                return requestedFileName.replace("YYYYMMDD", today);
            }
            Matcher reqDigits = EIGHT_DIGIT_DATE_PATTERN.matcher(requestedFileName);
            if (reqDigits.find()) {
                // Requester already supplied a dated filename (e.g. via scenario), keep as-is
                return requestedFileName;
            }
        }

        Matcher sampleDigits = sampleFileName != null ? EIGHT_DIGIT_DATE_PATTERN.matcher(sampleFileName) : null;
        if (sampleDigits != null && sampleDigits.find()) {
            // Sample already has date digits → reuse
            return sampleFileName;
        }

        // Nothing contained a date placeholder/digits → append today's stamp
        return appendDateBeforeExtension(sampleFileName != null ? sampleFileName : requestedFileName, today);
    }

    private String appendDateBeforeExtension(String baseName, String today) {
        if (baseName == null || baseName.isEmpty()) {
            return "TrancheUpload_" + today + ".xlsx";
        }
        int dot = baseName.lastIndexOf('.');
        if (dot > 0) {
            String name = baseName.substring(0, dot);
            String ext = baseName.substring(dot);
            return name + "_" + today + ext;
        }
        return baseName + "_" + today;
    }

    // -----------------------------
    // Excel update: update tranche IDs in workbook
    // -----------------------------
    private void updateTrancheIdsInExcel(String excelPath) {
        try (FileInputStream fis = new FileInputStream(excelPath);
             XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new RuntimeException("No sheets found in Excel: " + excelPath);
            }

            // Build a quick lookup for header → column index so we can fill any of the
            // date columns without hard-coding spreadsheet positions.
            Map<String, Integer> columnIndexMap = buildColumnIndexMap(sheet);
            Integer trancheIdCol = columnIndexMap.get("trancheid");
            if (trancheIdCol == null) {
                throw new RuntimeException("Tranche_ID column not found in template: " + excelPath);
            }
            Integer trancheDescCol = columnIndexMap.get("tranchedescription");

            LocalDate baseTradeDate = LocalDate.now();
            DateTimeFormatter trancheIdDateFormatter6 = DateTimeFormatter.ofPattern("yyMMdd"); // For 6-digit dates
            DateTimeFormatter trancheIdDateFormatter4 = DateTimeFormatter.ofPattern("yyMM");   // For 4-digit dates
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH);
            Map<String, Set<String>> existingIdsByDateToken = new HashMap<>();

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;

                // All Tranche IDs use today's date (baseTradeDate)
                // Date columns alternate: row 1 = today, row 2 = tomorrow, row 3 = today, etc.
                LocalDate tradeDateForColumns = baseTradeDate.plusDays((r - 1) % 2);

                // Update Tranche ID: replace date part with today's date and ensure uniqueness
                // All IDs use today's date (baseTradeDate), not alternate days
                String newTid = updateTrancheIdCell(row, trancheIdCol, trancheDescCol, baseTradeDate,
                        trancheIdDateFormatter4, trancheIdDateFormatter6, existingIdsByDateToken);

                // Only update date columns if Tranche ID was successfully updated
                if (newTid != null) {
                    updateDateColumns(row, columnIndexMap, tradeDateForColumns, dateFormatter, dateTimeFormatter);
                }
            }

            // Write workbook to file - ensure all streams are closed
            try (FileOutputStream fos = new FileOutputStream(excelPath)) {
                workbook.write(fos);
                fos.flush(); // Ensure all data is written
            }
            // Workbook and FileInputStream are automatically closed by try-with-resources
            // Add small delay to ensure OS releases file lock
            Thread.sleep(200);

        } catch (Exception e) {
            throw new RuntimeException("Failed to update Tranche IDs/Dates in Excel: " + e.getMessage(), e);
        }
    }

    private Map<String, Integer> buildColumnIndexMap(Sheet sheet) {
        Map<String, Integer> map = new HashMap<>();
        Row header = sheet.getRow(0);
        if (header == null) {
            return map;
        }
        for (int c = 0; c < header.getLastCellNum(); c++) {
            Cell cell = header.getCell(c);
            if (cell == null) continue;
            String normalized = normalizeHeader(cell.toString());
            if (!normalized.isEmpty()) {
                map.put(normalized, c);
            }
        }
        return map;
    }

    private String normalizeHeader(String header) {
        if (header == null) return "";
        return header.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ENGLISH);
    }

    private String updateTrancheIdCell(Row row,
                                       int trancheIdCol,
                                       Integer trancheDescCol,
                                       LocalDate tradeDate,
                                       DateTimeFormatter dateFormatter4,
                                       DateTimeFormatter dateFormatter6,
                                       Map<String, Set<String>> existingIdsByDateToken) {
        // Extract the existing Tranche ID from the cell
        Cell cell = row.getCell(trancheIdCol);
        if (cell == null) return null;

        // Read cell value as string - use DataFormatter for proper conversion
        DataFormatter formatter = new DataFormatter();
        String oldTid = formatter.formatCellValue(cell).trim();
        if (oldTid == null || oldTid.isEmpty()) return null;

        // Parse the Tranche ID using the flexible pattern that supports both 4-digit and 6-digit dates
        // Examples:
        //   - MALI251130BUC10CY -> prefix=MALI, date=251130 (6 digits = yyMMdd), mid=BUC, num=10, suffix=CY
        //   - MALI2511BLNPPR03BD -> prefix=MALI, date=2511 (4 digits = yyMM), mid=BLNPPR, num=03, suffix=BD
        Matcher matcher = TRANCHE_ID_PATTERN.matcher(oldTid);
        String newTid;
        String numericStr = "1";
        int numericLength = 1;
        String prefix;
        String mid;
        String suffix;
        String dateToken;
        int originalDateLength = 0;

        if (matcher.matches()) {
            // Pattern matched: extract all components
            prefix = matcher.group(1);      // e.g., "MALI"
            String oldDate = matcher.group(2); // e.g., "251130" (6 digits) or "2511" (4 digits)
            originalDateLength = oldDate.length(); // Remember original date length (4 or 6)
            mid = matcher.group(3);         // e.g., "BUC" or "BLNPPR" (can contain numbers)
            numericStr = matcher.group(4);  // e.g., "10", "03"
            numericLength = numericStr.length(); // Preserve padding length
            suffix = matcher.group(5);      // e.g., "CY", "BD", "E", "F", "R"

            // Generate date token based on original date length:
            // - If original had 6 digits (yyMMdd), use 6-digit format
            // - If original had 4 digits (yyMM), use 4-digit format
            // This ensures the total Tranche ID length remains max 18 characters
            if (originalDateLength == 6) {
                dateToken = tradeDate.format(dateFormatter6); // yyMMdd format (6 digits)
            } else {
                dateToken = tradeDate.format(dateFormatter4); // yyMM format (4 digits)
            }
        } else {
            // Pattern didn't match: use entire old ID as prefix (fallback)
            prefix = oldTid;
            mid = "";
            suffix = "";
            dateToken = tradeDate.format(dateFormatter6); // Default to 6-digit format
        }

        // Get or create the set of existing IDs for this date token (for uniqueness checking)
        Set<String> existingForDate = existingIdsByDateToken.computeIfAbsent(
                dateToken, token -> new HashSet<>(getExistingTrancheIdsContaining(token)));

        // Build new Tranche ID: prefix + new date (yyMM or yyMMdd based on original) + mid + numeric + suffix
        int numericValue = Integer.parseInt(numericStr);
        newTid = prefix + dateToken + mid + padNumber(numericValue, numericLength) + suffix;

        // Ensure uniqueness: if the generated ID already exists, increment the numeric part
        while (existingForDate.contains(newTid)) {
            numericValue++;
            newTid = prefix + dateToken + mid + padNumber(numericValue, numericLength) + suffix;
        }

        // Update the cell with the new unique Tranche ID
        cell.setCellValue(newTid);

        // Add the new ID to the existing set for this date token
        existingForDate.add(newTid);

        // Keep descriptive column (Tranche_Description) in sync so downstream
        // validations always display the regenerated ID.
        updateTrancheDescription(row, trancheDescCol, oldTid, newTid);
        return newTid;
    }

    private void updateTrancheDescription(Row row, Integer descColIndex, String oldTid, String newTid) {
        if (descColIndex == null) return;
        Cell descCell = row.getCell(descColIndex);
        if (descCell == null) {
            descCell = row.createCell(descColIndex);
            descCell.setCellValue(newTid);
            return;
        }

        // Read cell value as string - use DataFormatter for proper conversion
        DataFormatter formatter = new DataFormatter();
        String desc = formatter.formatCellValue(descCell).trim();

        if (desc == null || desc.isEmpty()) {
            descCell.setCellValue(newTid);
        } else {
            // Replace old tranche ID (before first space) with new tranche ID
            int firstSpaceIndex = desc.indexOf(' ');
            if (firstSpaceIndex > 0) {
                // Extract part before first space and replace with new ID
                String partBeforeSpace = desc.substring(0, firstSpaceIndex);
                String restOfDesc = desc.substring(firstSpaceIndex);
                // Replace the part before space with new ID
                descCell.setCellValue(newTid + restOfDesc);
            } else {
                // No space found, use new ID only
                descCell.setCellValue(newTid);
            }
        }
    }

    private void updateDateColumns(Row row,
                                   Map<String, Integer> columnMap,
                                   LocalDate tradeDate,
                                   DateTimeFormatter dateFormatter,
                                   DateTimeFormatter dateTimeFormatter) {
        // Date ladder requested:
        // Trade (row dependent) → Settlement (+1y) → Expiry (+1y) → Maturity (=Expiry by default)
        LocalDate settlementDate = tradeDate.plusYears(1);
        LocalDate expiryDate = settlementDate.plusYears(1);
        LocalDate maturityDate = expiryDate;

        // Window start fixed to 12:00pm, client cut-off 1:00pm, end 3:00pm, cooling 1:00pm (same day).
        LocalDateTime windowStart = tradeDate.atTime(12, 0);
        LocalDateTime clientCutoff = tradeDate.atTime(13, 0);
        LocalDateTime windowEnd = tradeDate.atTime(15, 0);
        LocalDateTime coolingEnd = tradeDate.atTime(13, 0);

        writeStringCell(row, columnMap.get("tradedate"), tradeDate.format(dateFormatter));
        writeStringCell(row, columnMap.get("settlementdate"), settlementDate.format(dateFormatter));
        writeStringCell(row, columnMap.get("expirydate"), expiryDate.format(dateFormatter));
        writeStringCell(row, columnMap.get("maturitydate"), maturityDate.format(dateFormatter));
        writeStringCell(row, columnMap.get("windowperiodstartdatetime"), windowStart.format(dateTimeFormatter));
        writeStringCell(row, columnMap.get("clientordercutoffdatetime"), clientCutoff.format(dateTimeFormatter));
        writeStringCell(row, columnMap.get("windowperiodenddatetime"), windowEnd.format(dateTimeFormatter));
        writeStringCell(row, columnMap.get("coolingperiodenddatetime"), coolingEnd.format(dateTimeFormatter));
    }

    private void writeStringCell(Row row, Integer colIndex, String value) {
        if (colIndex == null || row == null || value == null) {
            return;
        }
        Cell cell = row.getCell(colIndex);
        if (cell == null) {
            cell = row.createCell(colIndex);
        }
        cell.setCellValue(value);
    }

    private String padNumber(int number, int length) {
        String format = "%0" + length + "d";
        return String.format(Locale.ENGLISH, format, number);
    }

    /**
     * Read persisted Uploaded_Tranche.xlsx to avoid collisions across runs.
     * Returns a list of tranche IDs that contain the given dateShort (yyMMdd).
     */
    private List<String> getExistingTrancheIdsContaining(String token) {
        List<String> ids = new ArrayList<>();

        // Default path where we store uploaded IDs
        File f = new File(UPLOADED_TRANCHE_PATH);
        if (!f.exists()) {
            return ids; // none exist yet
        }

        try (FileInputStream fis = new FileInputStream(f);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet = wb.getSheetAt(0);
            if (sheet == null) return ids;

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;
                Cell cell = row.getCell(0);
                if (cell == null) continue;
                String tid = cell.getStringCellValue();
                if (tid != null && tid.contains(token)) {
                    ids.add(tid);
                }
            }

        } catch (Exception e) {
            // If read fails, log and return empty. We avoid blocking the current upload due to historical file issues.
            return ids;
        }
        return ids;
    }

    /**
     * Persist given SUCCESS tranche records to Uploaded_Tranche.xlsx with today's date.
     * This creates the file if missing and appends rows.
     * Keeps all existing records and appends new ones.
     */
    public void saveTrancheRecords(List<TrancheUploadRecord> records) {
        if (records == null || records.isEmpty()) {
            return;
        }

        File file = new File(UPLOADED_TRANCHE_PATH);
        Workbook workbook = null;
        boolean createNew = false;
        DataFormatter dataFormatter = new DataFormatter();

        try {
            if (file.exists()) {
                try (FileInputStream fis = new FileInputStream(file)) {
                    workbook = new XSSFWorkbook(fis);
                }
            } else {
                // Create new workbook and header sheet
                workbook = new XSSFWorkbook();
                Sheet sheet = workbook.createSheet("TrancheIDs");
                Row header = sheet.createRow(0);
                header.createCell(0).setCellValue("Tranche ID");
                header.createCell(1).setCellValue("Window Period Start Datetime");
                header.createCell(2).setCellValue("Window Period End Datetime");
                header.createCell(3).setCellValue("Upload Date");
                createNew = true;
            }

            Sheet sheet = workbook.getSheetAt(0);
            LocalDate today = LocalDate.now();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            // Append new records (keep all old records, don't delete)
            int nextRow = sheet.getLastRowNum() + 1;
            String todayStr = today.format(dateFormatter);

            for (TrancheUploadRecord record : records) {
                Row row = sheet.createRow(nextRow++);
                row.createCell(0).setCellValue(record.getTrancheId());
                row.createCell(1).setCellValue(record.getWindowStart() != null ? record.getWindowStart() : "");
                row.createCell(2).setCellValue(record.getWindowEnd() != null ? record.getWindowEnd() : "");
                row.createCell(3).setCellValue(todayStr);
            }

            // Write back to disk (ensure parent folder exists)
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
                fos.flush();
            }

            // Small delay to ensure file lock is released
            Thread.sleep(200);

        } catch (Exception e) {
            throw new RuntimeException("Failed to persist Tranche IDs to Excel: " + e.getMessage(), e);
        } finally {
            if (workbook != null) {
                try { workbook.close(); } catch (IOException ignored) {}
            }
        }
    }

    // Helper method to copy cell content from source to destination
    private void copyCell(Cell sourceCell, Cell destCell) {
        switch (sourceCell.getCellType()) {
            case STRING:
                destCell.setCellValue(sourceCell.getStringCellValue());
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(sourceCell)) {
                    destCell.setCellValue(sourceCell.getDateCellValue());
                } else {
                    destCell.setCellValue(sourceCell.getNumericCellValue());
                }
                break;
            case BOOLEAN:
                destCell.setCellValue(sourceCell.getBooleanCellValue());
                break;
            case FORMULA:
                destCell.setCellFormula(sourceCell.getCellFormula());
                break;
            case BLANK:
                destCell.setBlank();
                break;
            default:
                break;
        }
    }

    public void deleteGeneratedUploadFile(String absolutePath) {
        if (absolutePath == null || absolutePath.isEmpty()) {
            return;
        }
        java.nio.file.Path path = Paths.get(absolutePath);
        if (!Files.exists(path)) {
            return;
        }

        // Retry deletion with delay - file might be locked by OS
        int maxRetries = 5;
        int retryDelayMs = 500;
        for (int i = 0; i < maxRetries; i++) {
            try {
                Files.delete(path);
                return; // Successfully deleted
            } catch (IOException e) {
                if (i < maxRetries - 1) {
                    // Wait before retry
                    try {
                        Thread.sleep(retryDelayMs);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("Interrupted while waiting to delete file: " + absolutePath, ie);
                    }
                } else {
                    // Last retry failed - log warning but don't throw (cleanup failures shouldn't break test)
                    System.err.println("Warning: Failed to delete generated upload file after " + maxRetries + " retries: " + absolutePath + " - " + e.getMessage());
                }
            }
        }
    }

    public static class TrancheUploadRecord {
        private final String trancheId;
        private final String windowStart;
        private final String windowEnd;

        public TrancheUploadRecord(String trancheId, String windowStart, String windowEnd) {
            this.trancheId = trancheId;
            this.windowStart = windowStart;
            this.windowEnd = windowEnd;
        }

        public String getTrancheId() {
            return trancheId;
        }

        public String getWindowStart() {
            return windowStart;
        }

        public String getWindowEnd() {
            return windowEnd;
        }
    }
}